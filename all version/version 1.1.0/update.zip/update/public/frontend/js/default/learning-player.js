"use strict";
const csrf_token = $("meta[name='csrf-token']").attr("content");

const placeholder = `<div class="player-placeholder">
<div class="preloader-two player">
    <div class="loader-icon-two player"><img src="${preloader_path}" alt="Preloader"></div>
</div>
</div>`;


function extractGoogleDriveVideoId(url) {
    // Regular expression to match Google Drive video URLs
    var googleDriveRegex = /(?:https?:\/\/)?(?:www\.)?(?:drive\.google\.com\/(?:uc\?id=|file\/d\/|open\?id=)|youtu\.be\/)([\w-]{25,})[?=&#]*/;

    // Try to match the URL with the regular expression
    var match = url.match(googleDriveRegex);

    // If a match is found, return the video ID
    if (match && match[1]) {
        return match[1];
    } else {
        return null;
    }
}

function showSidebar () {
    $(".wsus__course_sidebar").addClass("show");
}

function hideSidebar () {
    $(".wsus__course_sidebar").removeClass("show");
}



$(document).ready(function () {
    $(document).on('contextmenu', function(e) {
        e.preventDefault();
        return false;
    });
    $(document).on('keydown', function(e) {
        if (e.which === 123 || 
            (e.ctrlKey && e.shiftKey && (e.which === 'I'.charCodeAt(0) || e.which === 'J'.charCodeAt(0))) ||
            (e.ctrlKey && e.which === 'U'.charCodeAt(0))) {
            e.preventDefault();
            return false;
        }
    });

    $('.form-check').on("click", function () {
        $('.form-check').removeClass('item-active');
        $(this).addClass('item-active');
    })

    $(".lesson-item").on("click", function () {
        // hide sidebar
        hideSidebar();
        
        var lessonId = $(this).attr('data-lesson-id');
        var chapterId = $(this).attr('data-chapter-id');
        var courseId = $(this).attr('data-course-id');
        var type = $(this).attr('data-type');

        $.ajax({
            method: "POST",
            url: base_url + "/student/learning/get-file-info",
            data: {
                _token: csrf_token,
                lessonId: lessonId,
                chapterId: chapterId,
                courseId: courseId,
                type: type
            },
            beforeSend: function () {
                $('.video-payer').html(placeholder);
            },
            success: function (data) {
                // set lesson id on meta
                $("meta[name='lesson-id']").attr("content", data.file_info.id);
                let playerHtml;
                if (data.file_info.file_type != 'video' && data.file_info.type == 'lesson') {
                    if(data.file_info.storage == 'upload') {
                        playerHtml = `<div class="resource-file">
                        <div class="file-info">
                            <div class="text-center">
                                <img src="/uploads/website-images/resource-file.png" alt="">
                                <h6>Resource</h6>
                                <p>File Type: ${data.file_info.file_type}</p>
                                <p>Click on the download button for download the file</p>
                                <form action="/student/learning/resource-download/${data.file_info.id}" method="get" class="download-form">
                                    <button type="submit" class="btn btn-primary">Download</button>
                                </form>
                            </div>
                        </div>
                    </div>`
                    }else {
                        playerHtml = `<div class="resource-file">
                        <div class="file-info">
                            <div class="text-center">
                                <img src="/uploads/website-images/resource-file.png" alt="">
                                <h6>Resource</h6>
                                <p>File Type: ${data.file_info.file_type}</p>
                                <p>Click on the open button for check out the file</p>
                                <a href="${data.file_info.file_path}" target="_blank" class="btn btn-primary">Open</a>
                            </div>
                        </div>
                    </div>`
                    }
                } else if (data.file_info.storage == 'youtube' && data.file_info.type == 'lesson') {
                    playerHtml = `<video id="vid1" class="video-js vjs-default-skin" controls autoplay width="640" height="264"
                        data-setup='{ "techOrder": ["youtube"], "sources": [{ "type": "video/youtube", "src": "${data.file_info.file_path}"}] }'>
                        </video>`;
                } else if (data.file_info.storage == 'vimeo' && data.file_info.type == 'lesson') {
                    playerHtml = `<video id="vid1" class="video-js vjs-default-skin" controls autoplay width="640" height="264"
                        data-setup='{ "techOrder": ["vimeo"], "sources": [{ "type": "video/vimeo", "src": "${data.file_info.file_path}"}] }'>
                        </video>`;
                } else if (data.file_info.storage == 'upload' || data.file_info.storage == 'external_link' && data.file_info.type == 'lesson') {
                    playerHtml = `<video src="${data.file_info.file_path}" type="video/mp4" id="vid1" class="video-js vjs-default-skin" controls autoplay width="640" height="264"
                        data-setup='{}] }'>
                        </video>`;
                } else if (data.file_info.storage == 'google_drive' && data.file_info.type == 'lesson') {
                    playerHtml = `<iframe class="iframe-video" src="https://drive.google.com/file/d/${extractGoogleDriveVideoId(data.file_info.file_path)}/preview" width="640" height="680" allow="autoplay" frameborder="0" autoplay allowfullscreen></iframe>`
                } else if (data.file_info.storage == 'iframe') {
                    playerHtml = `<iframe class="iframe-video" src="${data.file_info.file_path}" frameborder="0" allowfullscreen></iframe>`
                } else if (data.file_info.type == 'quiz') {
                    playerHtml = `<div class="resource-file">
                    <div class="file-info">
                        <div class="text-center">
                            <img src="/uploads/website-images/quiz.png" alt="">
                            <h6 class="mt-2">${data.file_info.title}</h6>
                            <p>Please go to quiz page for mor information</p>
                            <a href="/student/learning/quiz/${data.file_info.id}" class="btn btn-primary">Start Quiz</a>
                        </div>
                    </div>
                </div>`
                }

                // Resetting any existing player instance
                if (videojs.getPlayers()['vid1']) {
                    videojs.getPlayers()['vid1'].dispose();
                }

                $('.video-payer').html(playerHtml);

                // Initializing the player
                if (document.getElementById('vid1')) {
                    videojs('vid1').ready(function () {
                        this.play();
                    });
                }

                // set lecture description
                $(".about-lecture").html(data.file_info.description || "No Description");

                // load qna's
                fetchQuestions(courseId, lessonId, 1, true);
            },
            error: function (xhr, status, error) {

            }
        })

    })

    $(".lesson-completed-checkbox").on("click", function () {
        let lessonId = $(this).attr('data-lesson-id');
        let type = $(this).attr('data-type');
        let checked = $(this).is(":checked") ? 1 : 0;
        $.ajax({
            method: "POST",
            url: base_url + "/student/learning/make-lesson-complete",
            data: {
                _token: csrf_token,
                lessonId: lessonId,
                status: checked,
                type: type
            },
            success: function (data) {
                if (data.status == 'success') {
                    toastr.success(data.message);
                } else if (data.status == "error") {
                    toastr.error(data.message);
                }
            },
            error: function (xhr, status, error) {
                let errors = xhr.responseJSON.errors;
                $.each(errors, function (key, value) {
                    toastr.error(value);
                })
            }
        })
    });


    // Course video button for small devices
    $(".wsus__course_header_btn").on("click", function () {
        $(".wsus__course_sidebar").addClass("show");
    });

    $(".wsus__course_sidebar_btn").on("click", function () {
        $(".wsus__course_sidebar").removeClass("show");
    });



})
