<?php

namespace Modules\InstructorRequest\database\seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class InstructorRequestSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void {
        // $this->call([]);
    }
}
