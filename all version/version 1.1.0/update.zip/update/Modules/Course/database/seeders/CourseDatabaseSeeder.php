<?php

namespace Modules\Course\database\seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CourseDatabaseSeeder extends Seeder {
    /**
     * Run the database seeds.
     */
    public function run(): void {
       
    }
}
