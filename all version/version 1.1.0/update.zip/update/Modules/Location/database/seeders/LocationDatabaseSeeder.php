<?php

namespace Modules\Location\database\seeders;

use Illuminate\Database\Seeder;

class LocationDatabaseSeeder extends Seeder {
    /**
     * Run the database seeds.
     */
    public function run(): void {
        // $this->call([]);
    }
}
