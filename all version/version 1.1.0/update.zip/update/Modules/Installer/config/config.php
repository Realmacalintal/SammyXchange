<?php

return [
    'name' => 'Installer',
];
