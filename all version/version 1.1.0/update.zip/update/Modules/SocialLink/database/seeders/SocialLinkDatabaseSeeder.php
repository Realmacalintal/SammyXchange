<?php

namespace Modules\SocialLink\database\seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SocialLinkDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void {
        // $this->call([]);
    }
}
