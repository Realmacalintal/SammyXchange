<li class="nav-item">
    <a class="nav-link active show" id="google-data-layer-tab" data-toggle="tab" href="#google_data_layer_tab" role="tab"
        aria-controls="google-data-layer" aria-selected="false">{{ __('Google Tag Manager Data Layer') }}</a>
</li>


