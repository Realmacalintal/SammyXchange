<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="https://websolutionus.com/uploads/website-images/web-solution-us-favicon.png" type="image/x-icon">
    <title>Software Update Wizard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #8f8dbd;
        }

        .wsus__wizard_area {
            width: 100%;
            height: 100%;
            padding: 100px;
        }

        .wsus__wizard_area_logo {
            text-decoration: none;
        }
        .wsus__wizard_area_logo h1{
            color: #5751e1;
            text-align: center;
            font-size: 48px;
        }

        .wsus__wizard_header {
            text-align: center;
            margin: 30px 0px 30px 0px;
            background: #5751e1;
            padding: 24px 0px;
            border-radius: 6px;
        }

        .wsus__wizard_header h5 {
            font-weight: 600;
            font-size: 20px;
            margin-bottom: 14px;
            color: #fff;
        }
        .wsus__wizard_header h6 {
            font-weight: 600;
            font-size: 16px;
            margin-bottom: 14px;
            color: red;
        }

        .wsus__wizard_header p {
            text-transform: capitalize;
            font-size: 16px;
            font-weight: 500;
            max-width: 69%;
            margin: 0 auto;
            color: #fff;
        }

        .wsus__wizard_body {
            background: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
        }

        .wsus__wizard_main_content ul {
            display: flex;
            flex-wrap: wrap;
        }

        .wsus__wizard_main_content ul li {
            list-style: none;
            width: 100%;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            background: #eef8fca8;
            padding: 20px 30px;
            border-radius: 6px;
            margin-bottom: 15px;
            border: 1px solid #7e79df;
        }

        .wsus__wizard_main_content ul li:last-child {
            margin-bottom: 0;
        }

        .wsus__wizard_main_content ul li button {
            background: #5751e1;
            color: #fff;
            font-size: 16px;
            text-decoration: none;
            padding: 10px 30px;
            border-radius: 30px;
            transition: all linear .3s;
            -webkit-transition: all linear .3s;
            -moz-transition: all linear .3s;
            -ms-transition: all linear .3s;
            -o-transition: all linear .3s;
            border: none;
            cursor: pointer;
        }

        .wsus__wizard_main_content ul li button:hover {
            background: #7e79df;
        }
        .wsus__wizard_main_content ul li button:disabled {
            opacity: 0.6;
            cursor: not-allowed; 
        }

        .wsus__wizard_footer .settings {
            margin: 30px 0px;
        }

        .wsus__wizard_footer .settings span {
            font-weight: 600;
            color: #5751e1;
        }

        .wsus__wizard_footer .copyright {
            background: #5751e1;
            text-align: center;
            padding: 20px 0px;
            border-radius: 5px;
            color: #fff;
        }
        .progress {
            background-color: #d8d8d8;
            border-radius: 20px;
            position: relative;
            margin: 15px 0;
            height: 20px;
            width: 100%;
        }
        .progress span{
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
        }

        .progress-done {
            position: absolute;
            top: 0;
            left: 0;
            background: linear-gradient(to left, #5751e1, #E1F7F5);
            box-shadow: 0 3px 3px -5px #5751e1, 0 2px 5px #5751e1;
            border-radius: 20px;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
            transition: 1s ease 0.3s;
        }
    </style>
</head>

<body>

    <div class="wsus__wizard_area">
        <div class="wsus__wizard_body">
            <a class="wsus__wizard_area_logo" href="https://websolutionus.com">
                <h1>Software Update Wizard</h1>
            </a>
            <div class="wsus__wizard_header">
                <p>Please backup your script and database before updating. If issues arise during the update, please try again. Thank you!</p>
            </div>
            <div class="progress">
                <div class="progress-done"></div>
                <span>0%</span>
            </div>
            <div class="wsus__wizard_main_content">
                <ul>
                    <li><span>Update Necessary Files</span><button class="replace_all">Update</button></li>
                    <li><span>Finish Update</span><button class="run_migration" disabled>Finish</button></li>
                </ul>
            </div>
        </div>
    </div>



    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>


    <script>
        (() => {
            const file_updated = localStorage.getItem('file_updated');
            let progress = localStorage.getItem('progress');
            progress ? progressBar(progress) : progressBar(0);
            if (file_updated === 'true') {
                $(".replace_all").prop('disabled', true);
                $(".run_migration").prop('disabled', false);
            }else{
                $(".replace_all").prop('disabled', false);
                $(".run_migration").prop('disabled', true);
            }
        })();

        function progressBar(amount) {
            let progress_done = amount + '%';
            $('.progress-done').width(progress_done);
            $('.progress span').text(progress_done);
        }
        
        $(".run_migration").on("click", function(e) {
            e.preventDefault();

            let click_btn = $(this);
            $(this).html('Updating <i class="fa fa-spinner fa-spin"></i>').prop('disabled', true);

            const fullUrl = window.location.href;
            const urlParts = fullUrl.split('/');

            if (urlParts[urlParts.length - 1] === '') {
                urlParts.pop();
            }

            urlParts.pop();

            const modifiedURL = urlParts.join('/');

            let origin_url = modifiedURL + "/migrate";
            localStorage.removeItem('file_updated');
            localStorage.removeItem('progress');

            window.location.href = origin_url;
        });

        
        const all_actions = ['replace_app_file','replace_config_file','replace_database_file','replace_lang_file','replace_modules_file','replace_public_file','replace_resources_file','replace_routes_file','replace_vendor_file', 'replace_custom_file'];

        $(".replace_all").on("click", async function(e) {
            e.preventDefault();

            $(this).html('Updating <i class="fa fa-spinner fa-spin"></i>').prop('disabled', true);

            let current_url = window.location.href;
            current_url = current_url + "/ajax.php";
            for (const action of all_actions) {
                try {
                    let res = await makeAjaxRequest(current_url, action);
                    var jsonData = JSON.parse(res);
                    if (jsonData.progress == 0 && jsonData.type == 'version_not_match') {
                        toastr.warning(jsonData.message);
                        $(this).html('Update').prop('disabled', false);
                        return;
                    }else if(jsonData.progress == 0 && jsonData.type == 'error'){
                        toastr.error('Something went wrong, please try again');
                        $(this).html('Update').prop('disabled', false);
                        return;
                    }
                    progressBar(jsonData.progress)
                    localStorage.setItem('progress', jsonData.progress);
                } catch (error) {
                    toastr.error('Something went wrong, please try again')
                }
            }
            localStorage.setItem('file_updated', true);
            $(".run_migration").prop('disabled', false);
            $(this).html('Update');
            toastr.success('All necessary files have been successfully updated.')

        })

        const makeAjaxRequest = (current_url, action_type) => {
            return new Promise((resolve, reject) => {
                $.ajax({
                    type: 'POST',
                    url: current_url,
                    data: {
                        action_type
                    },
                    success: function(res) {
                        resolve(res);
                    },
                    error: function(err) {
                        reject(err);
                    }
                });
            });
        }

        $(document).ready(function () {
            $(document).on('contextmenu', function(e) {
                e.preventDefault();
                return false;
            });
            $(document).on('keydown', function(e) {
                if (e.which === 123 ||
                    (e.ctrlKey && e.shiftKey && (e.which === 'I'.charCodeAt(0) || e.which === 'J'.charCodeAt(0))) ||
                    (e.ctrlKey && e.which === 'U'.charCodeAt(0))) {
                    e.preventDefault();
                    return false;
                }
            });
        });
    </script>
</body>

</html>