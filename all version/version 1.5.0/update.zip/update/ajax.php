<?php

/**
 * all ajax call will be handle from here
 * */
class Updator {

    public function __construct() {
        $versionFilePath = '../version.json';

        if (file_exists($versionFilePath) || is_readable($versionFilePath)) {
            $versionFile = json_decode(file_get_contents($versionFilePath));
            if (method_exists($this, $_POST['action_type'])) {
                if ($versionFile->version == '1.4.0') {
                    $this->{$_POST['action_type']}($_POST);
                } else {
                    $this->message([
                        'type'     => 'version_not_match',
                        'progress' => 0,
                        'message' => "Update to version 1.5.0 requires version 1.4.0",
                    ]);
                }
            }else {
                $this->message([
                    'type'     => 'error',
                    'progress' => 0,
                ]);
            }
        }
    }

    public function replace_app_file() {
        $update_file_path = 'app';
        $old_file_path = '../app';
        $this->ReplaceFileFolder($update_file_path, $old_file_path);

        $this->message([
            'type'     => 'success',
            'progress' => 10,
        ]);
    }

    public function replace_database_file() {
        $update_file_path = 'database';
        $old_file_path = '../database';

        $this->ReplaceFileFolder($update_file_path, $old_file_path);

        $this->message([
            'type'     => 'success',
            'progress' => 20,
        ]);
    }
    public function replace_lang_file() {
        $folderPath = '../lang';
        $newData = [
            "Resource" => "Resource",
            "Click on the download button for download the file" => "Click on the download button for download the file",
            "Lesson is started" => "Lesson is started",
            "This lesson has now started. The lesson will end on " => "This lesson has now started. The lesson will end on ",
            "Lesson is finished" => "Lesson is finished",
            "This lesson is finished. You cant join it." => "This lesson is finished. You cant join it.",
            "Lesson is not started yet" => "Lesson is not started yet",
            "This lesson will be started on" => "This lesson will be started on",
            "Open in Website" => "Open in Website",
            "credential missing" => "credential missing",
            "Open" => "Open",
            "Click on the open button for check out the file" => "Click on the open button for check out the file",
            "Please go to quiz page for mor information" => "Please go to quiz page for mor information",
            "Start Quiz" => "Start Quiz",
            "Theme Three" => "Theme Three",
            "Home Three" => "Home Three",
            "Short Title" => "Short Title",
            "About Campus history" => "About Campus history",
            "Watch our" => "Watch our",
            "Video" => "Video",
            "year" => "year",
            "of Institutes" => "of Institutes",
            "Choose Perfect Academic Courses" => "Choose Perfect Academic Courses",
            "when known printer took a galley of type scrambl edmake" => "when known printer took a galley of type scrambl edmake",
            "Take a Tour" => "Take a Tour",
            "Join With Us" => "Join With Us",
            "Together We Go Far" => "Together We Go Far",
            "Through research and discovery, we are changing the world." => "Through research and discovery, we are changing the world.",
            "Testimonial section" => "Testimonial section",
            "Home Four" => "Home Four",
            "Theme Four" => "Theme Four",
            "Find Courses" => "Find Courses",
            "Professional Courses" => "Professional Courses",
            "For a better future" => "For a better future",
            "10,000+ unique online courses" => "10,000+ unique online courses",
            "Our Most Popular Courses" => "Our Most Popular Courses",
            "Finding Your Right Courses" => "Finding Your Right Courses",
            "Get Started" => "Get Started",
            "Why Choose Us" => "Why Choose Us",
            "Our Top Categories" => "Our Top Categories",
            "Your Creative and Passionate Business Coach" => "Your Creative and Passionate Business Coach",
            "Header Topbar" => "Header Topbar",
            "Topbar Social Icons" => "Topbar Social Icons",
            "Cursor Style" => "Cursor Style",
            "Join our teaching team and inspire the next generation!" => "Join our teaching team and inspire the next generation!",
            "Get Started Now" => "Get Started Now",
            "Real Reviews" => "Real Reviews",
        ];

        if (is_dir($folderPath)) {
            $files = scandir($folderPath);
            foreach ($files as $file) {
                if (pathinfo($file, PATHINFO_EXTENSION) === 'json') {
                    $filePath = $folderPath . '/' . $file;
                    $jsonContent = file_get_contents($filePath);
                    $existingData = json_decode($jsonContent, true);
                    $mergedData = array_merge($existingData, $newData);
                    $updatedJsonContent = json_encode($mergedData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
                    file_put_contents($filePath, $updatedJsonContent);
                }
            }
        }

        $this->message([
            'type'     => 'success',
            'progress' => 40,
        ]);
    }
    public function replace_modules_file() {
        $update_file_path = 'Modules';
        $old_file_path = '../Modules';

        $this->ReplaceFileFolder($update_file_path, $old_file_path);

        $this->message([
            'type'     => 'success',
            'progress' => 50,
        ]);
    }
    public function replace_public_file() {
        $update_file_path = 'public';
        $old_file_path = '../public';

        $this->ReplaceFileFolder($update_file_path, $old_file_path);

        $this->message([
            'type'     => 'success',
            'progress' => 60,
        ]);
    }
    public function replace_resources_file() {
        $update_file_path = 'resources';
        $old_file_path = '../resources';

        $this->ReplaceFileFolder($update_file_path, $old_file_path);

        $this->message([
            'type'     => 'success',
            'progress' => 75,
        ]);
    }
    public function replace_routes_file() {
        $update_file_path = 'routes';
        $old_file_path = '../routes';

        $this->ReplaceFileFolder($update_file_path, $old_file_path);

        $this->message([
            'type'     => 'success',
            'progress' => 85,
        ]);
    }
    public function replace_vendor_file() {
        $update_file_path = 'vendor';
        $old_file_path = '../vendor';

        $this->ReplaceVendorFileFolder( $update_file_path, $old_file_path );

        $this->message( [
            'type' => 'success',
            'progress' => 95,
        ] );
    }

    public function ReplaceFileFolder($update_file_path, $old_file_path) {

        $all_update_views = $this->get_file_list_by_directory($update_file_path);
        $all_old_views = $this->get_file_list_by_directory($old_file_path);

        foreach ($all_update_views as $new_file) {

            $not_allow_to_update_files_list = [
                "dynamic-style.css",
                "dynamic-style.js",
                ".git",
                ".idea",
                ".DS_Store",
            ]; //only file/folder

            if (in_array($new_file, $not_allow_to_update_files_list)) {
                continue;
            }

            if (is_dir($update_file_path . '/' . $new_file)) {
                $old_file = array_search($new_file, $all_old_views);

                $folder_name = isset($all_old_views[$old_file]) ? $all_old_views[$old_file] : '';

                if (!file_exists($old_file_path . '/' . $new_file)) {
                    if (!mkdir($concurrentDirectory = $old_file_path . '/' . $new_file) && !is_dir($concurrentDirectory)) {
                        throw new \RuntimeException(sprintf('Directory "%s" was not created', $concurrentDirectory));
                    }
                    $folder_name = $new_file;
                }
                $this->ReplaceFileFolder($update_file_path . '/' . $new_file, $old_file_path . '/' . $folder_name);
            } else {
                $file_index = array_search($new_file, $all_old_views);
                $update_file_path_new = $update_file_path;
                $script_old_file_path = $old_file_path;

                $folder_name = $all_old_views[$file_index] ?? $new_file;
                $update_able_file_size = $this->get_file_size($update_file_path_new . '/' . $new_file);
                $script_able_file_size = $this->get_file_size($script_old_file_path . '/' . $folder_name);

                $this->update_file($update_file_path . '/' . $new_file, $script_old_file_path . '/' . $folder_name);
                if (!is_dir($script_old_file_path) && !file_exists($script_old_file_path . '/' . $new_file)) {
                    file_put_contents($script_old_file_path . '/' . $new_file, file_get_contents($update_file_path_new . '/' . $new_file));
                }
            }
        }
    }

    public function get_file_list_by_directory($dir) {
        $get_file = array_diff(scandir($dir), array('.', '..', '.DS_Store', ".git"));
        return $get_file;
    }

    public function get_file_size($file_path) {
        return file_exists($file_path) ? filesize($file_path) : 0;
    }

    public function update_file($update_file, $old_file) {
        $update_data = file_get_contents($update_file);
        file_put_contents($old_file, $update_data);
    }
    public function ReplaceVendorFileFolder( $update_file_path, $old_file_path ) {

        $all_update_views = $this->get_file_list_by_directory( $update_file_path );
        $all_old_views = $this->get_file_list_by_directory( $old_file_path );
        foreach ( $all_update_views as $new_file ) {
            if ( is_dir( $update_file_path . '/' . $new_file ) ) {
                $old_file = array_search( $new_file, $all_old_views );
                $folder_name = isset( $all_old_views[$old_file] ) ? $all_old_views[$old_file] : '';
                if ( !file_exists( $old_file_path . '/' . $new_file ) ) {
                    if ( !mkdir( $concurrentDirectory = $old_file_path . '/' . $new_file ) && !is_dir( $concurrentDirectory ) ) {
                        throw new \RuntimeException( sprintf( 'Directory "%s" was not created', $concurrentDirectory ) );
                    }
                    $folder_name = $new_file;
                }
                $this->ReplaceFileFolder( $update_file_path . '/' . $new_file, $old_file_path . '/' . $folder_name );
            } else {
                $file_index = array_search( $new_file, $all_old_views );
                $update_file_path_new = $update_file_path;
                $script_old_file_path = $old_file_path;

                $folder_name = $all_old_views[$file_index] ?? $new_file;
                $update_able_file_size = $this->get_file_size( $update_file_path_new . '/' . $new_file );
                $script_able_file_size = $this->get_file_size( $script_old_file_path . '/' . $folder_name );

                $this->update_file( $update_file_path . '/' . $new_file, $script_old_file_path . '/' . $folder_name );

                if ( !is_dir( $script_old_file_path ) && !file_exists( $script_old_file_path . '/' . $new_file ) ) {
                    file_put_contents( $script_old_file_path . '/' . $new_file, file_get_contents( $update_file_path_new . '/' . $new_file ) );
                }
            }
        }
    }

    public function message($msg) {
        echo json_encode($msg);
    }
}

new Updator();
