<section class="faq__area faq__area_3 mt-0">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="faq__content">
                    <div class="section__title pb-10">
                        <span class="sub-title">{{ __('Faqs') }}</span>
                        <h2 class="title">{!! clean(processText($faqSection->translation?->title)) !!}</h2>
                    </div>
                    <p>{!! clean(processText($faqSection->translation?->sub_title)) !!}</p>
                    <div class="faq__wrap">
                        <div class="accordion" id="accordionExample">
                            @foreach ($faqs as $faq)
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button {{ $loop->first ? '' : 'collapsed' }}"
                                            type="button" data-bs-toggle="collapse"
                                            data-bs-target="#collapse{{ $faq->id }}" aria-expanded="true"
                                            aria-controls="collapse{{ $faq->id }}">
                                            {{ $faq->translation?->question }}
                                        </button>
                                    </h2>
                                    <div id="collapse{{ $faq->id }}"
                                        class="accordion-collapse collapse {{ $loop->first ? 'show' : '' }}"
                                        data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>
                                                {{ $faq->translation?->answer }}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="faq__img-wrap tg-svg">
                    <div class="faq__round-text">
                        <div class="curved-circle {{ getSessionLanguage() == 'en' ? '' : 'd-none' }}">
                            * {{ __('Education') }} * {{ __('System ') }} * {{ __('can') }} * {{ __('Make ') }} * {{ __('Change ') }} *
                        </div>
                    </div>
                    <div class="faq__img">
                        <img src="{{ asset($faqSection->image) }}" alt="img">
                        <div class="shape-one">
                            <img src="{{ asset('frontend/img/others/faq_shape01.svg') }}"
                                class="injectable tg-motion-effects4" alt="img">
                        </div>
                        <div class="shape-two">
                            <span class="svg-icon" id="faq-svg"
                                data-svg-icon="{{ asset('frontend/img/others/faq_shape02.svg') }}"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
