<li class="nav-item dropdown <?php echo e(isRoute(['admin.coupon.index', 'admin.coupon-history'], 'active')); ?>">
    <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-money-bill-wave"></i>
        <span><?php echo e(__('Manage Coupon')); ?> </span>

    </a>
    <ul class="dropdown-menu">
        <li class="<?php echo e(isRoute('admin.coupon.index', 'active')); ?>"><a class="nav-link" href="<?php echo e(route('admin.coupon.index')); ?>"><?php echo e(__('Coupon List')); ?></a></li>
    </ul>
</li>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/Coupon\resources/views/sidebar.blade.php ENDPATH**/ ?>