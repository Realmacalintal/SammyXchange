<li class="nav-item dropdown <?php echo e(isRoute(['admin.site-appearance.*', 'admin.section-setting.*', 'admin.site-color-setting.*'], 'active')); ?>">
    <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-swatchbook"></i>
        <span><?php echo e(__('Appearance')); ?> </span>

    </a>
    <ul class="dropdown-menu">
        <li class="<?php echo e(isRoute('admin.site-appearance.*', 'active')); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.site-appearance.index')); ?>"><?php echo e(__('Site Themes')); ?></a></li>
        <li class="<?php echo e(isRoute('admin.section-setting.*', 'active')); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.section-setting.index')); ?>"><?php echo e(__('Section Setting')); ?></a></li>
        <li class="<?php echo e(isRoute('admin.site-color-setting.*', 'active')); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.site-color-setting.index')); ?>"><?php echo e(__('Site Colors')); ?></a></li>
    </ul>
</li>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/SiteAppearance\resources/views/sidebar.blade.php ENDPATH**/ ?>