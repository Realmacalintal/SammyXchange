<li class="<?php echo e(isRoute('admin.certificate-builder.*', 'active')); ?>">
    <a class="nav-link" href="<?php echo e(route('admin.certificate-builder.index')); ?>"><i class="fas fa-certificate"></i>
        <span><?php echo e(__('Certificate Builder')); ?></span>
    </a>
</li><?php /**PATH D:\laragon\www\skillgro\main_files\Modules/CertificateBuilder\resources/views/sidebar.blade.php ENDPATH**/ ?>