<?php $__env->startSection('meta_title', $seo_setting['home_page']['seo_title']); ?>
<?php $__env->startSection('meta_description', $seo_setting['home_page']['seo_description']); ?>
<?php $__env->startSection('meta_keywords', ''); ?>

<?php $__env->startSection('contents'); ?>
    <?php if($sectionSetting?->hero_section): ?>
        <!-- banner-area -->
        <?php echo $__env->make('frontend.home-three.sections.banner-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- banner-area-end -->
    <?php endif; ?>

    <?php if($sectionSetting?->our_features_section): ?>
        <!-- features-area -->
        <?php echo $__env->make('frontend.home-three.sections.features-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- features-area-end -->
    <?php endif; ?>
    <?php if($sectionSetting?->top_category_section): ?>
        <!-- categories-area -->
        <?php echo $__env->make('frontend.home-three.sections.category-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- categories-area-end -->
    <?php endif; ?>
    <?php if($sectionSetting?->about_section): ?>
        <!-- about-area -->
        <?php echo $__env->make('frontend.home-three.sections.about-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- about-area-end -->
    <?php endif; ?>

    <?php if($sectionSetting?->featured_course_section): ?>
        <!-- course-area -->
        <?php echo $__env->make('frontend.home-three.sections.course-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- course-area-end -->
    <?php endif; ?>

    <?php if($sectionSetting?->faq_section): ?>
        <!-- faq-area -->
        <?php echo $__env->make('frontend.home-three.sections.faq-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- faq-area-end -->
    <?php endif; ?>

    <?php if($sectionSetting?->counter_section): ?>
        <!-- fact-area -->
        <?php echo $__env->make('frontend.home-three.sections.fact-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- fact-area-end -->
    <?php endif; ?>

    <?php if($sectionSetting?->banner_section): ?>
        <!-- instructor-area-two -->
        <?php echo $__env->make('frontend.home-three.sections.join-us-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- instructor-area-two-end -->
    <?php endif; ?>
    <?php if($sectionSetting?->testimonial_section): ?>
        <!-- testimonial-area -->
        <?php echo $__env->make('frontend.home-three.sections.testimonial-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- testimonial-area-end -->
    <?php endif; ?>
    <?php if($sectionSetting?->latest_blog_section): ?>
        <!-- blog-area -->
        <?php echo $__env->make('frontend.home-three.sections.blog-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- blog-area-end -->
    <?php endif; ?>
    <?php if($sectionSetting?->news_letter_section): ?>
        <!-- newsletter-area -->
        <?php echo $__env->make('frontend.home-three.sections.newsletter-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- newsletter-area-end -->
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/home-three/index.blade.php ENDPATH**/ ?>