<li class="nav-item">
    <a class="nav-link active show" id="google-recaptcha-tab" data-toggle="tab" href="#google_recaptcha_tab" role="tab"
        aria-controls="google-recaptcha" aria-selected="false"><?php echo e(__('Google reCaptcha')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" id="google-tag-tab" data-toggle="tab" href="#google_tag_tab" role="tab"
        aria-controls="google-tag" aria-selected="false"><?php echo e(__('Google Tag Manager')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" id="google-analytic-tab" data-toggle="tab" href="#google_analytic_tab" role="tab"
        aria-controls="google-analytic" aria-selected="false"><?php echo e(__('Google Analytic')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" id="facebook-pixel-tab" data-toggle="tab" href="#facebook_pixel_tab" role="tab"
        aria-controls="facebook-pixel" aria-selected="false"><?php echo e(__('Facebook Pixel')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" id="social-login-tab" data-toggle="tab" href="#social_login_tab" role="tab"
        aria-controls="social-login" aria-selected="false"><?php echo e(__('Social Login')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" id="tawk-chat-tab" data-toggle="tab" href="#tawk_chat_tab" role="tab"
        aria-controls="tawk-chat" aria-selected="false"><?php echo e(__('Tawk Chat')); ?></a>
</li>


<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/GlobalSetting\resources/views/credientials/tabs/navbar.blade.php ENDPATH**/ ?>