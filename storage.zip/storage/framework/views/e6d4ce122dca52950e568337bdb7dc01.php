<?php
    $pendingWithdrawCount = \Modules\PaymentWithdraw\app\Models\WithdrawRequest::where('status', 'pending')->count();
?>
<li
    class="nav-item dropdown <?php echo e(isRoute(['admin.withdraw-method.*', 'admin.withdraw-list', 'admin.show-withdraw', 'admin.pending-withdraw-list'], 'active')); ?>">
    <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-holding-usd"></i><span
            class="<?php echo e($pendingWithdrawCount > 0 ? 'beep parent' : ''); ?>"><?php echo e(__('Withdraw Payment')); ?></span></a>

    <ul class="dropdown-menu">
        <li class="<?php echo e(isRoute('admin.withdraw-method.*', 'active')); ?>"><a class="nav-link"
                href="<?php echo e(route('admin.withdraw-method.index')); ?>"><?php echo e(__('Withdraw Method')); ?></a></li>

        <li class="<?php echo e(isRoute('admin.withdraw-list', 'active')); ?>"><a class="nav-link"
                href="<?php echo e(route('admin.withdraw-list')); ?>"><?php echo e(__('Withdraw list')); ?>

                <?php if($pendingWithdrawCount > 0): ?>
                    <small class="badge badge-danger ml-2"><?php echo e($pendingWithdrawCount); ?></small>
                <?php endif; ?>
            </a>
        </li>
    </ul>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/PaymentWithdraw\resources/views/admin/sidebar.blade.php ENDPATH**/ ?>