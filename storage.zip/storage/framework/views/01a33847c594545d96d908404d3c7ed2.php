<div class="tab-pane fade" id="mmaintenance_mode_tab" role="tabpanel">
    <div class="form-group">
        <div class="alert alert-warning alert-has-icon">
            <div class="alert-icon"><i class="far fa-lightbulb"></i></div>
            <div class="alert-body">
                <div class="alert-title"><?php echo e(__('Warning')); ?></div>
                <?php echo e(__('If you enable maintenance mode, regular users wont be able to access the website. Please make sure to inform users about the temporary unavailability.')); ?>

            </div>
        </div>
        <input onchange="changeMaintenanceModeStatus()" <?php echo e($setting->maintenance_mode ? 'checked' : ''); ?>

            id="maintenance_mode_toggle" type="checkbox" data-toggle="toggle" data-on="<?php echo e(__('Active')); ?>"
            data-off="<?php echo e(__('Inactive')); ?>" data-onstyle="success" data-offstyle="danger">
    </div>
    <form action="<?php echo e(route('admin.update-maintenance-mode')); ?>" method="POST"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group ">
            <label><?php echo e(__('Maintenance Mode Image')); ?><span class="text-danger"></span></label>
            <div id="image-preview-maintenance" class="image-preview">
                <label for="image-upload-maintenance" id="image-label-maintenance"><?php echo e(__('Image')); ?></label>
                <input type="file" name="maintenance_image" id="image-maintenance">
            </div>
            <?php $__errorArgs = ['maintenance_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for=""><?php echo e(__('Maintenance Mode Title')); ?> <span class="text-danger">*</span></label>
            <input type="text" name="maintenance_title" class="form-control"
                value="<?php echo e($setting->maintenance_title); ?>">
        </div>
        <div class="form-group">
            <label><?php echo e(__('Maintenance Mode Description')); ?> <span class="text-danger">*</span></label>
            <textarea name="maintenance_description" id="" cols="30" rows="10" class="summernote"><?php echo clean($setting->maintenance_description); ?></textarea>
        </div>
        <button class="btn btn-primary" type="submit"><?php echo e(__('Update')); ?></button>

    </form>
</div>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/GlobalSetting\resources/views/settings/sections/maintenance-mode.blade.php ENDPATH**/ ?>