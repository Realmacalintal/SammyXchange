<?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="review-part">
    <div class="course-review-head">
        <div class="review-author-thumb">
            <img src="<?php echo e(asset($review->user->image)); ?>" alt="img">
        </div>
        <div class="review-author-content">
            <div class="author-name">
                <h5 class="name"><?php echo e($review->user->name); ?> <span><?php echo e(formatDate($review->created_at)); ?></span></h5>
                <div class="author-rating">
                    <?php for($i = 0; $i < $review->rating; $i++): ?>
                    <i class="fas fa-star"></i>
                    <?php endfor; ?>
                </div>
            </div>
            <?php echo clean($review->review); ?>

        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

<?php endif; ?><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/pages/learning-player/partials/review-card.blade.php ENDPATH**/ ?>