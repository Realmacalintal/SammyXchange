<?php if(Module::isEnabled('SocialLink') && Route::has('admin.social-link.index')): ?>
    <li class="<?php echo e(isRoute('admin.social-link.*', 'active')); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.social-link.index')); ?>">
            <i class="fas fa-hashtag"></i> <span><?php echo e(__('Social Links')); ?></span>
        </a>
    </li>
<?php endif; ?>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/SocialLink\resources/views/sidebar.blade.php ENDPATH**/ ?>