<?php if(Module::isEnabled('Faq') && Route::has('admin.faq.index')): ?>
    <li class="<?php echo e(isRoute('admin.faq.*', 'active')); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.faq.index')); ?>">
            <i class="fas fa-question-circle"></i> <span><?php echo e(__('FAQS')); ?></span>
        </a>
    </li>
<?php endif; ?>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/Faq\resources/views/sidebar.blade.php ENDPATH**/ ?>