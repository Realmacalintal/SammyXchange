<link rel="stylesheet" href="<?php echo e(asset('backend/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/fontawesome/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/style.css')); ?>?v=<?php echo e($setting?->version); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/bootstrap-social.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/components.css')); ?>?v=<?php echo e($setting?->version); ?>">

<link rel="stylesheet" href="<?php echo e(asset('global/toastr/toastr.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/bootstrap4-toggle.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/dev.css')); ?>?v=<?php echo e($setting?->version); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/tagify.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/bootstrap-tagsinput.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/fontawesome-iconpicker.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/bootstrap-datepicker.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/clockpicker/dist/bootstrap-clockpicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/datetimepicker/jquery.datetimepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/iziToast.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('global/nice-select/nice-select.css')); ?>">
<?php if(session()->has('text_direction') && session()->get('text_direction') !== 'ltr'): ?>
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/rtl.css')); ?>?v=<?php echo e($setting?->version); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/dev_rtl.css')); ?>?v=<?php echo e($setting?->version); ?>">
<?php endif; ?><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/admin/partials/styles.blade.php ENDPATH**/ ?>