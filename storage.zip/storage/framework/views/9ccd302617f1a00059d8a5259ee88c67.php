<li
    class="nav-item dropdown <?php echo e(isRoute(['admin.all-customers','admin.all-instructors', 'admin.active-customers', 'admin.non-verified-customers', 'admin.banned-customers', 'admin.customer-show', 'admin.send-bulk-mail'], 'active')); ?>">
    <a href="javascript:void()" class="nav-link has-dropdown">
        <i class="fas fa-users"></i><span><?php echo e(__('Manage Users')); ?></span>
    </a>

    <ul class="dropdown-menu">
        <li class="<?php echo e(isRoute('admin.all-customers', 'active')); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.all-customers')); ?>">
                <?php echo e(__('All Students')); ?>

            </a>
        </li>

        <li class="<?php echo e(isRoute('admin.all-instructors', 'active')); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.all-instructors')); ?>">
                <?php echo e(__('All Instructors')); ?>

            </a>
        </li>

        <li class="<?php echo e(isRoute('admin.active-customers', 'active')); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.active-customers')); ?>">
                <?php echo e(__('Active Users')); ?>

            </a>
        </li>

        <li class="<?php echo e(isRoute('admin.non-verified-customers', 'active')); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.non-verified-customers')); ?>">
                <?php echo e(__('Non verified')); ?>

            </a>
        </li>

        <li class="<?php echo e(isRoute('admin.banned-customers', 'active')); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.banned-customers')); ?>">
                <?php echo e(__('Banned Users')); ?>

            </a>
        </li>

        <li class="<?php echo e(isRoute('admin.send-bulk-mail', 'active')); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.send-bulk-mail')); ?>">
                <?php echo e(__('Send bulk mail')); ?>

            </a>
        </li>
    </ul>
</li>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/Customer\resources/views/sidebar.blade.php ENDPATH**/ ?>