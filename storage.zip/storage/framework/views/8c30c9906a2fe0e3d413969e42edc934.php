<div class="tab-pane fade" id="custom_pagination_tab" role="tabpanel">
    <form action="<?php echo e(route('admin.update-custom-pagination')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th width="50%"><?php echo e(__('Section Name')); ?></th>
                    <th width="50%"><?php echo e(__('Quantity')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $custom_paginations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $custom_pagination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($custom_pagination->section_name); ?></td>
                        <td>
                            <input type="number" value="<?php echo e($custom_pagination->item_qty); ?>" name="quantities[]"
                                class="form-control">
                            <input type="hidden" value="<?php echo e($custom_pagination->id); ?>" name="ids[]">
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
        <button class="btn btn-primary"><?php echo e(__('Update')); ?></button>
    </form>
</div>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/GlobalSetting\resources/views/settings/sections/custom-paginate.blade.php ENDPATH**/ ?>