<li
    class="nav-item dropdown <?php echo e(isRoute('admin.subscriber-list') || isRoute('admin.send-mail-to-newsletter') ? 'active' : ''); ?>">
    <a href="javascript:void()" class="nav-link has-dropdown"><i
            class="fas fa-bullhorn"></i><span><?php echo e(__('NewsLetter')); ?></span></a>

    <ul class="dropdown-menu">
        <li class="<?php echo e(isRoute('admin.subscriber-list') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.subscriber-list')); ?>">
                <?php echo e(__('Subscriber List')); ?>

            </a>
        </li>

        <li class="<?php echo e(isRoute('admin.send-mail-to-newsletter') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.send-mail-to-newsletter')); ?>">
                <?php echo e(__('Send bulk mail')); ?>

            </a>
        </li>
    </ul>
</li>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/NewsLetter\resources/views/sidebar.blade.php ENDPATH**/ ?>