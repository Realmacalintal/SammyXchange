<?php $__env->startSection('title'); ?>
    <title><?php echo e(__('Menu Builder')); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-content'); ?>
    <!-- Main Content -->
    <div class="main-content">
        <div id="loader" class="LoadingOverlay d-none">
            <div class="Line-Progress">
                <div class="indeterminate"></div>
            </div>
        </div>
        <section class="section">
            <div class="section-header">
                <h1><?php echo e(__('Menu Builder')); ?></h1>
            </div>

            <div class="section-body">
                <div class="row">
                    <div class="col-12">
                        <?php echo $__env->make('menubuilder::menu-builder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('backend/menubuilder/style.css')); ?>">
    <style>
        #hwpwrap .spinner {
            background: url("<?php echo e(asset('backend/menubuilder/images/spinner.gif')); ?>") 0 0/20px 20px no-repeat;
        }
        @media print, (-o-min-device-pixel-ratio: 5 / 4), (-webkit-min-device-pixel-ratio: 1.25), (min-resolution: 120dpi) {
            #hwpwrap .spinner {
                background-image: url("<?php echo e(asset('backend/menubuilder/images/spinner-2x.gif')); ?>");
            }
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js'); ?>
    <?php echo $__env->make('menubuilder::script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\skillgro\main_files\Modules/Menubuilder\resources/views/index.blade.php ENDPATH**/ ?>