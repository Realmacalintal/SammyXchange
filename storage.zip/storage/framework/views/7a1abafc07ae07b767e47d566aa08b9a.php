<?php if(Module::isEnabled('Language') && Route::has('admin.blogs.index')): ?>
    <li
        class="nav-item dropdown <?php echo e(isRoute(['admin.blogs.*', 'admin.blog-category.*', 'admin.blog-comment.*'], 'active')); ?>">
        <a href="javascript:void()" class="nav-link has-dropdown"><i
                class="fas fa-newspaper"></i><span><?php echo e(__('Manage Blogs')); ?></span></a>

        <ul class="dropdown-menu">
            <?php if(auth()->guard('admin')->user()->can('blog.category.view')): ?>
                <li class="<?php echo e(isRoute('admin.blog-category.*', 'active')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.blog-category.index')); ?>">
                        <?php echo e(__('Category List')); ?>

                    </a>
                </li>
            <?php endif; ?>
            <?php if(auth()->guard('admin')->user()->can('blog.view')): ?>
                <li class="<?php echo e(isRoute('admin.blogs.*', 'active')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.blogs.index')); ?>">
                        <?php echo e(__('Post List')); ?>

                    </a>
                </li>
            <?php endif; ?>
            <?php if(auth()->guard('admin')->user()->can('blog.comment.view')): ?>
                <li class="<?php echo e(isRoute('admin.blog-comment.*', 'active')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.blog-comment.index')); ?>">
                        <?php echo e(__('Post Comments')); ?>

                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </li>
<?php endif; ?>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/Blog\resources/views/sidebar.blade.php ENDPATH**/ ?>