<?php $__env->startSection('meta_title', 'Login'. ' || ' . $setting->app_name); ?>
<?php $__env->startSection('contents'); ?>
    <!-- breadcrumb-area -->
    <?php if (isset($component)) { $__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Breadcrumb::resolve(['title' => __('Login'),'links' => [
            ['url' => route('home'), 'text' => __('Home')],
            ['url' => route('login'), 'text' => __('Login')],
        ]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Breadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c)): ?>
<?php $attributes = $__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c; ?>
<?php unset($__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c)): ?>
<?php $component = $__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c; ?>
<?php unset($__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c); ?>
<?php endif; ?>
    <!-- breadcrumb-area-end -->

    <!-- singUp-area -->
    <section class="singUp-area section-py-120">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-8">
                    <div class="singUp-wrap">
                        <h2 class="title"><?php echo e(__('Welcome back!')); ?></h2>
                        <p><?php echo e(__('Hey there! Ready to log in? Just enter your email and password below and you will be back in action in no time. Lets go!')); ?>

                        </p>
                        <?php if($setting->google_login_status == 'active'): ?>
                        <div class="account__social">
                            <a href="<?php echo e(route('auth.social', 'google')); ?>" class="account__social-btn">
                                <img src="<?php echo e(asset('frontend/img/icons/google.svg')); ?>" alt="img">
                                <?php echo e(__('Continue with google')); ?>

                            </a>
                        </div>
                        <div class="account__divider">
                            <span><?php echo e(__('or')); ?></span>
                        </div>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('user-login')); ?>" class="account__form">
                            <?php echo csrf_field(); ?>
                            <div class="form-grp">
                                <label for="email"><?php echo e(__('Email')); ?> <code>*</code></label>
                                <input id="email" type="text" placeholder="email" value="<?php echo e(old('email')); ?>" name="email">
                                <?php if (isset($component)) { $__componentOriginal32fc7fa7a4bdcf7e4010834194770ff6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal32fc7fa7a4bdcf7e4010834194770ff6 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\ValidationError::resolve(['name' => 'email'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\ValidationError::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal32fc7fa7a4bdcf7e4010834194770ff6)): ?>
<?php $attributes = $__attributesOriginal32fc7fa7a4bdcf7e4010834194770ff6; ?>
<?php unset($__attributesOriginal32fc7fa7a4bdcf7e4010834194770ff6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal32fc7fa7a4bdcf7e4010834194770ff6)): ?>
<?php $component = $__componentOriginal32fc7fa7a4bdcf7e4010834194770ff6; ?>
<?php unset($__componentOriginal32fc7fa7a4bdcf7e4010834194770ff6); ?>
<?php endif; ?>
                            </div>
                            <div class="form-grp">
                                <label for="password"><?php echo e(__('Password')); ?> <code>*</code></label>
                                <input id="password" type="password" placeholder="password" name="password">
                            </div>
                            <div class="account__check">
                                <div class="account__check-remember">
                                    <input type="checkbox" class="form-check-input" name="remember" value=""
                                        id="terms-check">
                                    <label for="terms-check" class="form-check-label"><?php echo e(__('Remember me')); ?></label>
                                </div>
                                <div class="account__check-forgot">
                                    <a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Forgot Password?')); ?></a>
                                </div>
                            </div>
                            <!-- g-recaptcha -->
                            <?php if(Cache::get('setting')->recaptcha_status === 'active'): ?>
                            <div class="form-grp mt-3">
                                <div class="g-recaptcha" data-sitekey="<?php echo e(Cache::get('setting')->recaptcha_site_key); ?>"></div>
                                <?php if (isset($component)) { $__componentOriginal32fc7fa7a4bdcf7e4010834194770ff6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal32fc7fa7a4bdcf7e4010834194770ff6 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\ValidationError::resolve(['name' => 'g-recaptcha-response'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\ValidationError::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal32fc7fa7a4bdcf7e4010834194770ff6)): ?>
<?php $attributes = $__attributesOriginal32fc7fa7a4bdcf7e4010834194770ff6; ?>
<?php unset($__attributesOriginal32fc7fa7a4bdcf7e4010834194770ff6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal32fc7fa7a4bdcf7e4010834194770ff6)): ?>
<?php $component = $__componentOriginal32fc7fa7a4bdcf7e4010834194770ff6; ?>
<?php unset($__componentOriginal32fc7fa7a4bdcf7e4010834194770ff6); ?>
<?php endif; ?>
                            </div>
                            <?php endif; ?>
                            <button type="submit" class="btn btn-two arrow-btn"><?php echo e(__('Sign In')); ?><img
                                    src="<?php echo e(asset('frontend/img/icons/right_arrow.svg')); ?>" alt="img"
                                    class="injectable"></button>
                        </form>
                        <div class="account__switch">
                            <p><?php echo e(__('Dont have an account?')); ?><a href="<?php echo e(route('register')); ?>"><?php echo e(__('Sign Up')); ?></a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- singUp-area-end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/auth/login.blade.php ENDPATH**/ ?>