<?php $__env->startSection('meta_title', __('All Instructors') . ' || ' . $setting->app_name); ?>
<?php $__env->startSection('contents'); ?>
    <!-- breadcrumb-area -->
    <?php if (isset($component)) { $__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Breadcrumb::resolve(['title' => __('All Instructors'),'links' => [['url' => route('home'), 'text' => __('Home')], ['url' => '', 'text' => __('All Instructors')]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Breadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c)): ?>
<?php $attributes = $__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c; ?>
<?php unset($__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c)): ?>
<?php $component = $__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c; ?>
<?php unset($__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c); ?>
<?php endif; ?>
    <!-- breadcrumb-area-end -->
    <!-- instructor-area -->
    <section class="instructor__area">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($instructor->courses()->where(['status' => 'active', 'is_approved' => 'approved'])->count() > 0): ?>
                <div class="col-xl-4 col-sm-6">
                    <div class="instructor__item">
                        <div class="instructor__thumb">
                            <a href="<?php echo e(route('instructor-details', ['id' => $instructor->id, 'slug' => Str::slug($instructor->name)])); ?>"><img src="<?php echo e(asset($instructor->image)); ?>"
                                    alt="img"></a>
                        </div>
                        <div class="instructor__content">
                            <h2 class="title"><a href="<?php echo e(route('instructor-details', ['id' => $instructor->id, 'slug' => Str::slug($instructor->name)])); ?>"><?php echo e($instructor->name); ?></a></h2>
                            <span class="designation"><?php echo e($instructor->job_title); ?></span>
                            <span><?php echo e($instructor->courses->count()); ?> <?php echo e(__('Courses')); ?></span>
                            <p class="avg-rating">
                                <i class="fas fa-star"></i>
                                <?php echo e(number_format($instructor->courses->avg('avg_rating'), 1)); ?> <?php echo e(__('Ratings')); ?>

                            </p>
                            <div class="instructor__social">
                                <ul class="list-wrap">
                                    <?php if($instructor->facebook): ?>
                                    <li><a href="<?php echo e($instructor->facebook); ?>"><i class="fab fa-facebook-f"></i></a></li>
                                  <?php endif; ?>
                                  <?php if($instructor->twitter): ?>
                                    <li><a href="<?php echo e($instructor->twitter); ?>"><i class="fab fa-twitter"></i></a></li>
                                  <?php endif; ?>
                                  <?php if($instructor->linkedin): ?>
                                    <li><a href="<?php echo e($instructor->linkedin); ?>"><i class="fab fa-linkedin"></i></a></li>
                                  <?php endif; ?>
                                  <?php if($instructor->github): ?>
                                    <li><a href="<?php echo e($instructor->github); ?>"><i class="fab fa-github"></i></a></li>
                                  <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <nav class="pagination__wrap mt-25">
                    <?php echo e($instructors->links()); ?>

                </nav>
            </div>
        </div>
    </section>
    <!-- instructor-area-end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/pages/all-instructors.blade.php ENDPATH**/ ?>