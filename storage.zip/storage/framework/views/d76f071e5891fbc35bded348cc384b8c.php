<section class="cta__area-three">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-10">
                <div class="cta__bg-three" data-background="<?php echo e(asset('frontend/img/bg/h7_cta_bg.jpg')); ?>">
                    <div class="cta__img-two">
                        <img src="<?php echo e(asset($bannerSection?->student_image)); ?>" alt="img">
                    </div>
                    <div class="cta__content-three">
                        <div class="content__left">
                            <h2 class="title"><?php echo e(__('Finding Your Right Courses')); ?></h2>
                            <p><?php echo e(__('Unlock your potential by joining our vibrant learning community')); ?></p>
                        </div>
                        <a href="<?php echo e(route('register')); ?>" class="btn arrow-btn"><?php echo e(__('Get Started')); ?> <img src="<?php echo e(asset('frontend/img/icons/right_arrow.svg')); ?>" alt="" class="injectable"></a>
                    </div>
                    <div class="cta__shape-two">
                        <img src="<?php echo e(asset('frontend/img/others/h7_cta_shape.svg')); ?>" alt="shape">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/home-four/sections/join-us.blade.php ENDPATH**/ ?>