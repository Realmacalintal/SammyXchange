<li class="<?php echo e(isRoute('admin.menubuilder.index', 'active')); ?>">
    <a class="nav-link" href="<?php echo e(route('admin.menubuilder.index')); ?>"><i class="fas fa-th"></i>
        <span><?php echo e(__('Menu Builder')); ?></span>
    </a>
</li>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/Menubuilder\resources/views/sidebar.blade.php ENDPATH**/ ?>