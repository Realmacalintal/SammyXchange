
<script>
  var base_url = "<?php echo e(url('/')); ?>";
  var preloader_path = "<?php echo e(asset(Cache::get('setting')->preloader)); ?>";
  
  var demo_mode_error = "<?php echo e(__('This Is Demo Version. You Can Not Change Anything')); ?>";
  var translation_success = "<?php echo e(__('Translated Successfully!')); ?>";
  var translation_processing = "<?php echo e(__('Translation Processing, please wait...')); ?>";
  var search_instructor_placeholder = "<?php echo e(__('Search for an instructor with email or name')); ?>";
  var Previous = "<?php echo e(__('Previous')); ?>";
  var Next = "<?php echo e(__('Next')); ?>";
  var basic_error_message = "<?php echo e(__('Something went wrong')); ?>";
  var discount = "<?php echo e(__('Discount')); ?>";
  var subscribe_now = "<?php echo e(__('Subscribe Now')); ?>";
  var submitting = "<?php echo e(__('Submitting')); ?>...";
</script><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/global/dynamic-js-variables.blade.php ENDPATH**/ ?>