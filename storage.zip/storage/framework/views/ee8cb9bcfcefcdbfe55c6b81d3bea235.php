<li class="<?php echo e(isRoute('admin.brand.*', 'active')); ?>">
    <a class="nav-link" href="<?php echo e(route('admin.brand.index')); ?>"><i class="fas fa-copyright"></i>
        <span><?php echo e(__('Brands')); ?></span>
    </a>
</li><?php /**PATH D:\laragon\www\skillgro\main_files\Modules/Brand\resources/views/sidebar.blade.php ENDPATH**/ ?>