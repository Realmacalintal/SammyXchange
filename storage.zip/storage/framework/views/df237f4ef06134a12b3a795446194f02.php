<!-- meta -->
<?php $__env->startSection('meta_title', __('Student Dashboard')); ?>
<!-- end meta -->

<?php $__env->startSection('contents'); ?>
    <!-- breadcrumb-area -->
    <?php if (isset($component)) { $__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Breadcrumb::resolve(['title' => __(''),'links' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Breadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c)): ?>
<?php $attributes = $__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c; ?>
<?php unset($__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c)): ?>
<?php $component = $__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c; ?>
<?php unset($__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c); ?>
<?php endif; ?>
    <!-- breadcrumb-area-end -->

    <!-- dashboard-area -->
    <section class="dashboard__area section-pb-120">
        <div class="container">
            <div class="dashboard__top-wrap">
                <div class="dashboard__top-bg" data-background="<?php echo e(asset(auth()->user()->cover)); ?>"></div>
                <div class="dashboard__instructor-info">
                    <div class="dashboard__instructor-info-left">
                        <div class="thumb">
                            <img src="<?php echo e(asset(auth()->user()->image)); ?>" alt="img">
                        </div>
                        <div class="content">
                            <h4 class="title"><?php echo e(auth()->user()->name); ?></h4>
                            <ul class="list-wrap">
                                <li>
                                    <img src="<?php echo e(asset('frontend/img/icons/envelope.svg')); ?>" alt="img" class="injectable">
                                    <?php echo e(auth()->user()->email); ?>

                                </li>
                                <?php if(auth()->user()->phone): ?>
                                <li>
                                    <img  src="<?php echo e(asset('frontend/img/icons/phone.svg')); ?>" alt="img" class="injectable">
                                    <?php echo e(auth()->user()->phone); ?>

                                </li>
                                <?php endif; ?>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="dashboard__instructor-info-right">
                        <?php if(instructorStatus() == 'approved'): ?>
                        <a href="<?php echo e(route('instructor.dashboard')); ?>" class="btn btn-two arrow-btn"><?php echo e(__('Instructor Dashboard')); ?> <img
                            src="<?php echo e(asset('frontend/img/icons/right_arrow.svg')); ?>" alt="img" class="injectable"></a>
                        <?php elseif(instructorStatus() != 'pending'): ?>
                        <a href="<?php echo e(route('become-instructor')); ?>" class="btn btn-two arrow-btn"><?php echo e(__('Become an Instructor')); ?> <img
                            src="<?php echo e(asset('frontend/img/icons/right_arrow.svg')); ?>" alt="img" class="injectable"></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3">
                    <?php echo $__env->make('frontend.student-dashboard.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-lg-9">
                    <?php echo $__env->yieldContent('dashboard-contents'); ?>
                </div>
            </div>
        </div>
    </section>
    <!-- dashboard-area-end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/student-dashboard/layouts/master.blade.php ENDPATH**/ ?>