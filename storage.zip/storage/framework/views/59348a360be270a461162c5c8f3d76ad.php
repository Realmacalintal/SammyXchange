<section class="choose__area-four tg-motion-effects section-py-140">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-lg-6 col-md-10">
                <div class="choose__img-four">
                    <div class="left__side">
                        <img src="<?php echo e(manageAssetImage('uploads/homepages/business/about_img.jpg', $aboutSection?->image)); ?>" alt="img" data-aos="fade-down" data-aos-delay="200">
                        <img src="<?php echo e(asset($aboutSection?->image_two)); ?>" alt="img" data-aos="fade-up" data-aos-delay="200">
                    </div>
                    <div class="right__side" data-aos="fade-left" data-aos-delay="400">
                        <img src="<?php echo e(asset($aboutSection?->image_three)); ?>" alt="img">
                        <a href="<?php echo e($aboutSection?->video_url); ?>" class="popup-video"><i class="fas fa-play"></i></a>
                    </div>
                    <img src="<?php echo e(asset('frontend/img/others/h7_choose_shape01.svg')); ?>" alt="shape" class="shape shape-one tg-motion-effects4">
                    <img src="<?php echo e(asset('frontend/img/others/h7_choose_shape02.svg')); ?>" alt="shape" class="shape shape-two alltuchtopdown">
                    <img src="<?php echo e(asset('frontend/img/others/h7_choose_shape03.svg')); ?>" alt="shape" class="shape shape-three tg-motion-effects7">
                </div>
            </div>
            <div class="col-lg-6">
                <div class="choose__content-four">
                    <div class="section__title mb-20">
                        <span class="sub-title"><?php echo e(__('Why Choose Us')); ?></span>
                        <h2 class="title bold"><?php echo clean(processText($aboutSection->translation?->title)); ?></h2>
                    </div>
                    <?php echo clean(processText($aboutSection->translation?->description)); ?>

                    <a href="<?php echo e($aboutSection?->button_url); ?>" class="btn arrow-btn btn-four"><?php echo e($aboutSection->translation?->button_text); ?> <img src="<?php echo e(asset('frontend/img/icons/right_arrow.svg')); ?>" alt="" class="injectable"></a>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/home-four/sections/about-area.blade.php ENDPATH**/ ?>