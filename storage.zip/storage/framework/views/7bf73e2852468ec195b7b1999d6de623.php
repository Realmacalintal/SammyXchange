<?php $__env->startSection('meta_title', 'Instructor Details' . ' || ' . $setting->app_name); ?>

<?php $__env->startSection('contents'); ?>
    <!-- breadcrumb-area -->
    <?php if (isset($component)) { $__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Breadcrumb::resolve(['title' => __('Instructor Details'),'links' => [['url' => route('home'), 'text' => __('Home')], ['url' => '', 'text' => __('Instructor Details')]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Breadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c)): ?>
<?php $attributes = $__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c; ?>
<?php unset($__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c)): ?>
<?php $component = $__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c; ?>
<?php unset($__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c); ?>
<?php endif; ?>
    <!-- breadcrumb-area-end -->

    <!-- instructor-details-area -->
    <section class="instructor__details-area section-pt-120 section-pb-90">
        <div class="container">
            <div class="row">
                <div class="col-xl-9">
                    <div class="instructor__details-wrap">
                        <div class="instructor__details-info">
                            <div class="instructor__details-thumb">
                                <img src="<?php echo e(asset($instructor->image)); ?>" alt="img">
                            </div>
                            <div class="instructor__details-content">
                                <div class="badges">
                                    <?php if($instructor->created_at->diffInDays(now()) >= $badges['registration_badge_three'][0]->condition_from): ?>
                                        <li><img src="<?php echo e(asset($badges['registration_badge_three'][0]->image)); ?>"
                                                alt="<?php echo e($badges['registration_badge_three'][0]->name); ?>"></li>
                                    <?php elseif(
                                        $instructor->created_at->diffInDays(now()) >= $badges['registration_badge_two'][0]->condition_from &&
                                            $instructor->created_at->diffInDays(now()) < $badges['registration_badge_two'][0]->condition_to): ?>
                                        <li><img src="<?php echo e(asset($badges['registration_badge_two'][0]->image)); ?>"
                                                alt="<?php echo e($badges['registration_badge_two'][0]->name); ?>"></li>
                                    <?php elseif(
                                        $instructor->created_at->diffInDays(now()) >= $badges['registration_badge_one'][0]->condition_from &&
                                            $instructor->created_at->diffInDays(now()) < $badges['registration_badge_one'][0]->condition_to): ?>
                                        <li><img src="<?php echo e(asset($badges['registration_badge_one'][0]->image)); ?>"
                                                alt="<?php echo e($badges['registration_badge_one'][0]->name); ?>"></li>
                                    <?php endif; ?>

                                    <?php if($instructor->courses->count() >= $badges['course_count_badge_three'][0]->condition_from): ?>
                                        <li><img src="<?php echo e(asset($badges['course_count_badge_three'][0]->image)); ?>"
                                                alt="<?php echo e($badges['course_count_badge_three'][0]->name); ?>"></li>
                                    <?php elseif(
                                        $instructor->courses->count() >= $badges['course_count_badge_two'][0]->condition_from &&
                                            $instructor->courses->count() < $badges['course_count_badge_two'][0]->condition_to): ?>
                                        <li><img src="<?php echo e(asset($badges['course_count_badge_two'][0]->image)); ?>"
                                                alt="<?php echo e($badges['course_count_badge_two'][0]->name); ?>"></li>
                                    <?php elseif(
                                        $instructor->courses->count() >= $badges['course_count_badge_one'][0]->condition_from &&
                                            $instructor->courses->count() < $badges['course_count_badge_one'][0]->condition_to): ?>
                                        <li><img src="<?php echo e(asset($badges['course_count_badge_one'][0]->image)); ?>"
                                                alt="<?php echo e($badges['course_count_badge_one'][0]->name); ?>"></li>
                                    <?php endif; ?>

                                    <?php if($instructor->courses->avg('avg_rating') >= $badges['course_rating_badge_three'][0]->condition_from): ?>
                                        <li><img src="<?php echo e(asset($badges['course_rating_badge_three'][0]->image)); ?>"
                                                alt="<?php echo e($badges['course_rating_badge_three'][0]->name); ?>"></li>
                                    <?php elseif(
                                        $instructor->courses->avg('avg_rating') >= $badges['course_rating_badge_two'][0]->condition_from &&
                                            $instructor->courses->avg('avg_rating') < $badges['course_rating_badge_two'][0]->condition_to): ?>
                                        <li><img src="<?php echo e(asset($badges['course_rating_badge_two'][0]->image)); ?>"
                                                alt="<?php echo e($badges['course_rating_badge_two'][0]->name); ?>"></li>
                                    <?php elseif(
                                        $instructor->courses->avg('avg_rating') >= $badges['course_rating_badge_one'][0]->condition_from &&
                                            $instructor->courses->avg('avg_rating') < $badges['course_rating_badge_one'][0]->condition_to): ?>
                                        <li><img src="<?php echo e(asset($badges['course_rating_badge_one'][0]->image)); ?>"
                                                alt="<?php echo e($badges['course_rating_badge_one'][0]->name); ?>"></li>
                                    <?php endif; ?>
                                    <?php
                                        $totalEnrollment = 0;
                                        foreach ($instructor->courses as $course) {
                                            $totalEnrollment += $course->enrollments->count();
                                        }
                                    ?>

                                    <?php if($totalEnrollment >= $badges['course_enroll_badge_three'][0]->condition_from): ?>
                                        <li><img src="<?php echo e(asset($badges['course_enroll_badge_three'][0]->image)); ?>"
                                                alt="<?php echo e($badges['course_enroll_badge_three'][0]->name); ?>"></li>
                                    <?php elseif(
                                        $totalEnrollment >= $badges['course_enroll_badge_two'][0]->condition_from &&
                                            $totalEnrollment < $badges['course_enroll_badge_two'][0]->condition_to): ?>
                                        <li><img src="<?php echo e(asset($badges['course_enroll_badge_two'][0]->image)); ?>"
                                                alt="<?php echo e($badges['course_enroll_badge_two'][0]->name); ?>"></li>
                                    <?php elseif(
                                        $totalEnrollment >= $badges['course_enroll_badge_one'][0]->condition_from &&
                                            $totalEnrollment < $badges['course_enroll_badge_one'][0]->condition_to): ?>
                                        <li><img src="<?php echo e(asset($badges['course_enroll_badge_one'][0]->image)); ?>"
                                                alt="<?php echo e($badges['course_enroll_badge_one'][0]->name); ?>"></li>
                                    <?php endif; ?>

                                </div>
                                <h2 class="title"><?php echo e($instructor->name); ?></h2>
                                <span class="designation"><?php echo e($instructor->job_title); ?></span>
                                <ul class="list-wrap">
                                    <li class="avg-rating"><i
                                            class="fas fa-star"></i>(<?php echo e(number_format($instructor->courses->avg('avg_rating'), 1)); ?>

                                        <?php echo e(__('Reviews')); ?>)</li>
                                    <li><i class="far fa-envelope"></i><a
                                            href="mailto:<?php echo e($instructor->email); ?>"><?php echo e($instructor->email); ?></a></li>
                                    <?php if($instructor?->country?->name): ?>
                                        <li><i class="fas fa-search-location"></i><a
                                                href="javascript:;"><?php echo e($instructor?->country?->name); ?></a></li>
                                    <?php endif; ?>
                                </ul>
                                <p><?php echo e($instructor->short_bio); ?></p>
                                <div class="instructor__details-social">
                                    <ul class="list-wrap">
                                        <?php if($instructor->facebook): ?>
                                            <li><a href="<?php echo e($instructor->facebook); ?>"><i class="fab fa-facebook-f"></i></a>
                                            </li>
                                        <?php endif; ?>
                                        <?php if($instructor->twitter): ?>
                                            <li><a href="<?php echo e($instructor->twitter); ?>"><i class="fab fa-twitter"></i></a>
                                            </li>
                                        <?php endif; ?>
                                        <?php if($instructor->linkedin): ?>
                                            <li><a href="<?php echo e($instructor->linkedin); ?>"><i class="fab fa-linkedin"></i></a>
                                            </li>
                                        <?php endif; ?>
                                        <?php if($instructor->github): ?>
                                            <li><a href="<?php echo e($instructor->github); ?>"><i class="fab fa-github"></i></a></li>
                                        <?php endif; ?>
                                        <?php if($instructor->website): ?>
                                            <li><a href="<?php echo e($instructor->website); ?>"><i class="fas fa-link"></i></a></li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="instructor__details-biography">
                            <h4 class="title"><?php echo e(__('Biography')); ?></h4>
                            <p><?php echo clean(nl2br($instructor->bio)); ?></p>
                        </div>
                        <div class="instructor__details-Skill">
                            <h4 class="title"><?php echo e(__('Experience')); ?></h4>
                            <!-- Timeline 1 - Bootstrap Brain Component -->
                            <div class="bsb-timeline-1">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-10 col-md-8 col-xl-8">

                                            <ul class="timeline">
                                                <?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="timeline-item">
                                                        <div class="timeline-body">
                                                            <div class="timeline-content">
                                                                <div class="card border-0">
                                                                    <div class="card-body p-0">
                                                                        <h6 class="card-subtitle text-secondary mb-1">
                                                                            <?php echo e(formatDate($experience->start_date)); ?> -
                                                                            <?php echo e($experience->current == 1 ? 'Present' : formatDate($experience->end_date)); ?>

                                                                        </h6>
                                                                        <h5 class="card-title mb-3">
                                                                            <?php echo e($experience->company); ?></h5>
                                                                        <h6 class="card-subtitle text-secondary mb-1">
                                                                            <?php echo e($experience->position); ?>

                                                                        </h6>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="instructor__details-Skill">
                            <h4 class="title"><?php echo e(__('Education')); ?></h4>
                            <div class="bsb-timeline-1">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-10 col-md-8 col-xl-6">

                                            <ul class="timeline">
                                                <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="timeline-item">
                                                        <div class="timeline-body">
                                                            <div class="timeline-content">
                                                                <div class="card border-0">
                                                                    <div class="card-body p-0">
                                                                        <h6 class="card-subtitle text-secondary mb-1">
                                                                            <?php echo e(formatDate($education->start_date)); ?> -
                                                                            <?php echo e($education->current == 1 ? 'Present' : formatDate($education->end_date)); ?>

                                                                        </h6>

                                                                        <h5 class="card-title mb-3">
                                                                            <?php echo e($education->organization); ?></h5>
                                                                            <h6 class="card-subtitle text-secondary mb-1">
                                                                                <?php echo e($education->degree); ?>

                                                                            </h6>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <?php if($courses->count() > 0): ?>
                            <div class="instructor__details-courses">
                                <div class="row align-items-center mb-30">
                                    <div class="col-md-8">
                                        <h2 class="main-title"><?php echo e(__('My Courses')); ?></h2>
                                        <p><?php echo e(__('Checkout my latest courses')); ?></p>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="instructor__details-nav">
                                            <button class="courses-button-prev"><i
                                                    class="flaticon-arrow-right"></i></button>
                                            <button class="courses-button-next"><i
                                                    class="flaticon-arrow-right"></i></button>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper courses-swiper-active-two">
                                    <div class="swiper-wrapper">
                                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="swiper-slide">
                                                <div class="courses__item shine__animate-item">
                                                    <div class="courses__item-thumb">
                                                        <a href="<?php echo e(route('course.show', $course->slug)); ?>"
                                                            class="shine__animate-link">
                                                            <img src="<?php echo e(asset($course->thumbnail)); ?>" alt="img">
                                                        </a>
                                                    </div>
                                                    <div class="courses__item-content">
                                                        <ul class="courses__item-meta list-wrap">
                                                            <li class="courses__item-tag">
                                                                <a
                                                                    href="course.html"><?php echo e($course->category->translation->name); ?></a>
                                                            </li>
                                                            <li class="avg-rating"><i class="fas fa-star"></i>
                                                                <?php echo e(number_format($course->reviews()->avg('rating'), 1) ?? 0); ?>

                                                            </li>
                                                        </ul>
                                                        <h5 class="title"><a
                                                                href="<?php echo e(route('course.show', $course->slug)); ?>"><?php echo e(truncate($course->title, 50)); ?></a>
                                                        </h5>
                                                        <p class="author"><?php echo e(__('By')); ?> <a
                                                                href="<?php echo e(route('instructor-details', ['id' => $course->instructor->id, 'slug' => Str::slug($course->instructor->name)])); ?>"><?php echo e($course->instructor->name); ?></a>
                                                        </p>
                                                        <div class="courses__item-bottom">
                                                            <?php if(in_array($course->id, session('enrollments') ?? [])): ?>
                                                                <div class="button">
                                                                    <a href="<?php echo e(route('student.enrolled-courses')); ?>"
                                                                        class="already-enrolled-btn" data-id="">
                                                                        <span class="text"><?php echo e(__('Enrolled')); ?></span>
                                                                        <i class="flaticon-arrow-right"></i>
                                                                    </a>
                                                                </div>
                                                            <?php elseif($course->enrollments->count() >= $course->capacity && $course->capacity != null): ?>
                                                                <div class="button">
                                                                    <a href="javascript:;" class=""
                                                                        data-id="<?php echo e($course->id); ?>">
                                                                        <span class="text"><?php echo e(__('Booked')); ?></span>
                                                                        <i class="flaticon-arrow-right"></i>
                                                                    </a>
                                                                </div>
                                                            <?php else: ?>
                                                                <div class="button">
                                                                    <a href="javascript:;" class="add-to-cart"
                                                                        data-id="<?php echo e($course->id); ?>">
                                                                        <span
                                                                            class="text"><?php echo e(__('Add To Cart')); ?></span>
                                                                        <i class="flaticon-arrow-right"></i>
                                                                    </a>
                                                                </div>
                                                            <?php endif; ?>
                                                            <?php if($course->price == 0): ?>
                                                                <h5 class="price"><?php echo e(__('Free')); ?></h5>
                                                            <?php elseif($course->price > 0 && $course->discount > 0): ?>
                                                                <h5 class="price"><?php echo e(currency($course->discount)); ?></h5>
                                                            <?php else: ?>
                                                                <h5 class="price"><?php echo e(currency($course->price)); ?></h5>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-xl-3">
                    <div class="instructor__sidebar">
                        <h4 class="title"><?php echo e(__('Quick Contact')); ?></h4>
                        <p><?php echo e(__('Feel free to contact me through mail')); ?>!</p>
                        <form action="<?php echo e(route('quick-connect', $instructor->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-grp">
                                <input type="text" placeholder="Name" name="name">
                            </div>
                            <div class="form-grp">
                                <input type="email" placeholder="E-mail" name="email">
                            </div>
                            <div class="form-grp">
                                <input type="text" placeholder="subject" name="subject">
                            </div>
                            <div class="form-grp">
                                <textarea name="message" placeholder="Type Message"></textarea>
                            </div>
                            <?php if(Cache::get('setting')->recaptcha_status === 'active'): ?>
                                <div class="form-group mt-3">
                                    <div class="g-recaptcha overflow-hidden"
                                        data-sitekey="<?php echo e(Cache::get('setting')->recaptcha_site_key); ?>"></div>
                                </div>
                            <?php endif; ?>
                            <button type="submit" class="btn arrow-btn"><?php echo e(__('Send Message')); ?> <img
                                    src="<?php echo e(asset('frontend/img/icons/right_arrow.svg')); ?>" alt="img"
                                    class="injectable"></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- instructor-details-area-end -->
<?php $__env->stopSection(); ?>
<?php if(session('instructorQuickContact') && $setting->google_tagmanager_status == 'active' && $marketing_setting?->instructor_contact): ?>
    <?php
        $instructorQuickContact = session('instructorQuickContact');
        session()->forget('instructorQuickContact');
    ?>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(function() {
                dataLayer.push({
                    'event': 'instructorQuickContact',
                    'contact_info': <?php echo json_encode($instructorQuickContact, 15, 512) ?>
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/pages/instructor-details.blade.php ENDPATH**/ ?>