<?php if(Module::isEnabled('Language') && Route::has('admin.languages.index')): ?>
<li class="<?php echo e(Route::is('admin.languages.*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('admin.languages.index')); ?>">
        <i class="fas fa-language"></i> <span><?php echo e(__('Manage Language')); ?></span>
    </a>
</li>
<?php endif; ?>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/Language\resources/views/sidebar.blade.php ENDPATH**/ ?>