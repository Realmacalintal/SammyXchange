<div class="tab-pane fade" id="google_analytic_tab" role="tabpanel">
    <form action="<?php echo e(route('admin.update-google-analytic')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for=""><?php echo e(__('Status')); ?></label>
            <select name="google_analytic_status" id="tawk_allow" class="form-control">
                <option <?php echo e($setting?->google_analytic_status == 'active' ? 'selected' : ''); ?> value="active">
                    <?php echo e(__('Enable')); ?></option>
                <option <?php echo e($setting?->google_analytic_status == 'inactive' ? 'selected' : ''); ?> value="inactive">
                    <?php echo e(__('Disable')); ?></option>
            </select>
        </div>

        <div class="form-group">
            <label for=""><?php echo e(__('Analytic Tracking Id')); ?></label>
            <?php if(env('APP_MODE') == 'DEMO'): ?>
                <input type="text" class="form-control" name="google_analytic_id" value="ANA-34343434-TEST-ID">
            <?php else: ?>
                <input type="text" class="form-control" name="google_analytic_id"
                    value="<?php echo e($setting?->google_analytic_id); ?>">
            <?php endif; ?>
        </div>

        <button class="btn btn-primary"><?php echo e(__('Update')); ?></button>
    </form>
</div><?php /**PATH D:\laragon\www\skillgro\main_files\Modules/GlobalSetting\resources/views/credientials/sections/google-analytic.blade.php ENDPATH**/ ?>