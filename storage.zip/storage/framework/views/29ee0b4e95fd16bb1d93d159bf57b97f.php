<div class="tab-pane fade" id="facebook_pixel_tab" role="tabpanel">
    <form action="<?php echo e(route('admin.update-facebook-pixel')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <label for=""><?php echo e(__('Status')); ?></label>
            <select name="pixel_status" id="tawk_allow" class="form-control">
                <option <?php echo e($setting->pixel_status == 'active' ? 'selected' : ''); ?> value="active"><?php echo e(__('Enable')); ?>

                </option>
                <option <?php echo e($setting->pixel_status == 'inactive' ? 'selected' : ''); ?> value="inactive">
                    <?php echo e(__('Disable')); ?></option>
            </select>
        </div>

        <div class="form-group">
            <label for=""><?php echo e(__('Facebook App Id')); ?></label>
            <?php if(env('APP_MODE') == 'DEMO'): ?>
                <input type="text" value="PIXEL-APP-434334-DEMO-ID" class="form-control" name="pixel_app_id">
            <?php else: ?>
                <input type="text" value="<?php echo e($setting->pixel_app_id); ?>" class="form-control" name="pixel_app_id">
            <?php endif; ?>


        </div>
        <button class="btn btn-primary"><?php echo e(__('Update')); ?></button>
    </form>
</div>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/GlobalSetting\resources/views/credientials/sections/facebook-pixel.blade.php ENDPATH**/ ?>