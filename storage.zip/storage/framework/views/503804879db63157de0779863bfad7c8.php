<?php if(Module::isEnabled('FooterSetting') && Route::has('admin.footersetting.index')): ?>
    <li class="<?php echo e(isRoute('admin.footersetting.*', 'active')); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.footersetting.index')); ?>">
            <i class="fas fa-shoe-prints"></i> <span><?php echo e(__('Footer Setting')); ?></span>
        </a>
    </li>
<?php endif; ?>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/FooterSetting\resources/views/sidebar.blade.php ENDPATH**/ ?>