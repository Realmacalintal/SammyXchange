<li class="<?php echo e(Route::is('admin.paymentgateway') ? 'active' : ''); ?>"><a class="nav-link"
        href="<?php echo e(route('admin.paymentgateway')); ?>"><?php echo e(__('More Gateways')); ?></a> </li>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/PaymentGateway\resources/views/sidebar.blade.php ENDPATH**/ ?>