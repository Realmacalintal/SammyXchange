<!-- Modal -->
<div class="modal fade dynamic-modal modal-lg" tabindex="-1" aria-labelledby="dynamic-modalLabel" aria-hidden="true" data-bs-backdrop='static'>
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="d-flex justify-content-center align-items:center p-3">
                <div class="spinner-border" role="status">
                    <span class="visually-hidden"><?php echo e(__('Loading')); ?>...</span>
                </div>
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/partials/modal.blade.php ENDPATH**/ ?>