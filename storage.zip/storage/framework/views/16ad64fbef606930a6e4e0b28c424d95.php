<?php $__env->startSection('meta_title', $seo_setting['course_page']['seo_title']); ?>
<?php $__env->startSection('meta_description', $seo_setting['course_page']['seo_description']); ?>

<?php $__env->startSection('contents'); ?>
    <!-- breadcrumb-area -->
    <?php if (isset($component)) { $__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Breadcrumb::resolve(['title' => __('Courses'),'links' => [['url' => route('home'), 'text' => __('Home')], ['url' => '', 'text' => __('Courses')]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Breadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c)): ?>
<?php $attributes = $__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c; ?>
<?php unset($__attributesOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c)): ?>
<?php $component = $__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c; ?>
<?php unset($__componentOriginalcc52fffb9c918b8f3f4cf5faa6f3a53c); ?>
<?php endif; ?>
    <!-- breadcrumb-area-end -->

    <!-- all-courses -->
    <section class="all-courses-area section-py-120 top-baseline">
        <div class="container position-relative">
            <div class="preloader-two d-none">
                <div class="loader-icon-two"><img src="<?php echo e(asset(Cache::get('setting')->preloader)); ?>" alt="Preloader"></div>
            </div>
            <div class="row">
                <div class="col-xl-3 col-lg-4">
                    <div class="courses__sidebar_area">
                        <div class="courses__sidebar_button d-lg-none">
                            <h4><?php echo e(__('filter')); ?></h4>
                        </div>
                        <aside class="courses__sidebar">
                            <div class="courses-widget">
                                <h4 class="widget-title"><?php echo e(__('Categories')); ?></h4>
                                <div class="courses-cat-list">
                                    <ul class="list-wrap">
                                        <?php $__currentLoopData = $categories->sortBy('translation.name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <div class="form-check">
                                                    <input class="form-check-input main-category-checkbox" type="radio"
                                                        name="main_category" value="<?php echo e($category->slug); ?>"
                                                        id="cat_<?php echo e($category->id); ?>">
                                                    <label class="form-check-label"
                                                        for="cat_<?php echo e($category->id); ?>"><?php echo e($category->translation->name); ?></label>
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <div class="show-more">
                                    </div>
                                </div>
                            </div>

                            <div class="sub-category-holder "></div>
                            <div class="courses-widget">
                                <h4 class="widget-title"><?php echo e(__('Language')); ?></h4>
                                <div class="courses-cat-list">
                                    <ul class="list-wrap">

                                        <li>
                                            <div class="form-check">
                                                <input class="form-check-input language-checkbox" type="checkbox"
                                                    value="" id="lang">
                                                <label class="form-check-label"
                                                    for="lang"><?php echo e(__('All Language')); ?></label>
                                            </div>
                                        </li>
                                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <div class="form-check">
                                                    <input class="form-check-input language-checkbox" type="checkbox"
                                                        value="<?php echo e($language->id); ?>" id="lang_<?php echo e($language->id); ?>">
                                                    <label class="form-check-label"
                                                        for="lang_<?php echo e($language->id); ?>"><?php echo e($language->name); ?></label>
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>
                                </div>
                                <div class="show-more">
                                </div>
                            </div>
                            <div class="courses-widget">
                                <h4 class="widget-title"><?php echo e(__('Price')); ?></h4>
                                <div class="courses-cat-list">
                                    <ul class="list-wrap">
                                        <li>
                                            <div class="form-check">
                                                <input class="form-check-input price-checkbox" type="checkbox"
                                                    value="" id="price_1">
                                                <label class="form-check-label"
                                                    for="price_1"><?php echo e(__('All Price')); ?></label>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="form-check">
                                                <input class="form-check-input price-checkbox" type="checkbox"
                                                    value="free" id="price_2">
                                                <label class="form-check-label" for="price_2"><?php echo e(__('Free')); ?></label>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="form-check">
                                                <input class="form-check-input price-checkbox" type="checkbox"
                                                    value="paid" id="price_3">
                                                <label class="form-check-label" for="price_3"><?php echo e(__('Paid')); ?></label>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="courses-widget">
                                <h4 class="widget-title"><?php echo e(__('Skill level')); ?></h4>
                                <div class="courses-cat-list">
                                    <ul class="list-wrap">
                                        <li>
                                            <div class="form-check">
                                                <input class="form-check-input level-checkbox" type="checkbox"
                                                    value="" id="difficulty_1">
                                                <label class="form-check-label"
                                                    for="difficulty_1"><?php echo e(__('All Levels')); ?></label>
                                            </div>
                                        </li>
                                        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <div class="form-check">
                                                    <input class="form-check-input level-checkbox" type="checkbox"
                                                        value="<?php echo e($level->id); ?>" id="difficulty_<?php echo e($level->id); ?>">
                                                    <label class="form-check-label"
                                                        for="difficulty_<?php echo e($level->id); ?>"><?php echo e($level->translation->name); ?></label>
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </aside>
                    </div>
                </div>
                <div class="col-xl-9 col-lg-8">
                    <div class="courses-top-wrap courses-top-wrap">
                        <div class="row align-items-center">
                            <div class="col-md-5">
                                <div class="courses-top-left">
                                    <p><?php echo e(__('Total')); ?> <span class="course-count">0</span> <?php echo e(__('courses found')); ?>

                                    </p>
                                </div>
                            </div>
                            <div class="col-md-7">
                                <div class="d-flex justify-content-center align-items-center flex-wrap">
                                    <div class="courses-top-right m-0 ms-md-auto">
                                        <span class="sort-by"><?php echo e(__('Sort By')); ?>:</span>
                                        <div class="courses-top-right-select">
                                            <select name="orderby" class="orderby">
                                                <option value="desc"><?php echo e(__('Latest to Oldest')); ?></option>
                                                <option value="asc"><?php echo e(__('Oldest to Latest')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="grid" role="tabpanel"
                            aria-labelledby="grid-tab">
                            <div
                                class="course-holder row courses__grid-wrap row-cols-1 row-cols-xl-3 row-cols-lg-2 row-cols-md-2 row-cols-sm-1">
                                
                            </div>

                            <div class="pagination-wrap">
                                <div class="pagination">
                                    
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- all-courses-end -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('frontend/js/default/course-page.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/pages/course.blade.php ENDPATH**/ ?>