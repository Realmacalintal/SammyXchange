<section class="testimonial__area-five section-pb-120">
    <div class="container">
        <div class="swiper-container testimonial-active-four">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <div class="row align-items-center justify-content-center testimonial__content-four">
                            <div class="col-xl-6 col-lg-6 col-md-8">
                                <div class="testimonial__img-three testimonial__img-four tg-svg">
                                    <img src="<?php echo e(manageAssetImage('uploads/homepages/business/testimonial.png', $testimonial->image)); ?>"
                                        alt="img">
                                    <div class="banner__review" data-aos="fade-right" data-aos-delay="400">
                                        <div class="icon">
                                            <img src="<?php echo e(asset('frontend/img/icons/star.svg')); ?>" alt=""
                                                class="injectable">
                                        </div>
                                        <h6 class="title"><?php echo e($testimonial->rating); ?>/5
                                            <span><?php echo e(__('Real Reviews')); ?></span>
                                        </h6>
                                    </div>
                                    <div class="testimonial__img-icon">
                                        <img src="<?php echo e(asset('frontend/img/icons/quote02.svg')); ?>" alt=""
                                            class="injectable">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6">
                                <div class="testimonial__content-three">
                                    <div class="section__title mb-25">
                                        <span class="sub-title"><?php echo e(__('Our Testimonials')); ?></span>
                                        <h2 class="title bold"><?php echo e(__('What Students Think and Say About Us')); ?></h2>
                                    </div>

                                    <div class="testimonial__item-four">
                                        <div class="rating">
                                            <?php for($i = 0; $i < $testimonial->rating; $i++): ?>
                                                <i class="fas fa-star"></i>
                                            <?php endfor; ?>
                                        </div>
                                        <p>“ <?php echo e($testimonial->translation->comment); ?> ”</p>
                                        <div class="testimonial__bottom-two">
                                            <h4 class="title"><?php echo e($testimonial->translation->name); ?></h4>
                                            <span><?php echo e($testimonial->translation->designation); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                
                <div class="col-xl-6 col-lg-6 ms-auto">
                    <div class="testimonial-pagination testimonial-pagination-two"></div>
                </div>
            </div>
            
        </div>
    </div>
</section>
<?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/home-four/sections/testimonial-area.blade.php ENDPATH**/ ?>