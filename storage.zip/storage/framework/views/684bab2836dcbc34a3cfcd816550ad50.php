<?php if(Module::isEnabled('Location')): ?>
    <li
        class="nav-item dropdown <?php echo e(isRoute(['admin.country.*', 'admin.state.*', 'admin.city.*'], 'active')); ?>">
        <a href="javascript:void()" class="nav-link has-dropdown"><i class="fas fa-location-arrow"></i><span><?php echo e(__('Locations')); ?></span></a>

        <ul class="dropdown-menu">
            <li class="<?php echo e(isRoute('admin.country.*', 'active')); ?>">
                <a class="nav-link" href="<?php echo e(route('admin.country.index')); ?>">
                    <?php echo e(__('Countries')); ?>

                </a>
            </li>
        </ul>
    </li>
<?php endif; ?>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/Location\resources/views/sidebar.blade.php ENDPATH**/ ?>