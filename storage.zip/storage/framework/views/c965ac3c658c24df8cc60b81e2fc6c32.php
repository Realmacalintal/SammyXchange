<section class="faq__area faq__area_3 mt-0">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="faq__content">
                    <div class="section__title pb-10">
                        <span class="sub-title"><?php echo e(__('Faqs')); ?></span>
                        <h2 class="title"><?php echo clean(processText($faqSection->translation?->title)); ?></h2>
                    </div>
                    <p><?php echo clean(processText($faqSection->translation?->sub_title)); ?></p>
                    <div class="faq__wrap">
                        <div class="accordion" id="accordionExample">
                            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button <?php echo e($loop->first ? '' : 'collapsed'); ?>"
                                            type="button" data-bs-toggle="collapse"
                                            data-bs-target="#collapse<?php echo e($faq->id); ?>" aria-expanded="true"
                                            aria-controls="collapse<?php echo e($faq->id); ?>">
                                            <?php echo e($faq->translation?->question); ?>

                                        </button>
                                    </h2>
                                    <div id="collapse<?php echo e($faq->id); ?>"
                                        class="accordion-collapse collapse <?php echo e($loop->first ? 'show' : ''); ?>"
                                        data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>
                                                <?php echo e($faq->translation?->answer); ?>

                                            </p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="faq__img-wrap tg-svg">
                    <div class="faq__round-text">
                        <div class="curved-circle <?php echo e(getSessionLanguage() == 'en' ? '' : 'd-none'); ?>">
                            * <?php echo e(__('Education')); ?> * <?php echo e(__('System ')); ?> * <?php echo e(__('can')); ?> * <?php echo e(__('Make ')); ?> * <?php echo e(__('Change ')); ?> *
                        </div>
                    </div>
                    <div class="faq__img">
                        <img src="<?php echo e(asset($faqSection->image)); ?>" alt="img">
                        <div class="shape-one">
                            <img src="<?php echo e(asset('frontend/img/others/faq_shape01.svg')); ?>"
                                class="injectable tg-motion-effects4" alt="img">
                        </div>
                        <div class="shape-two">
                            <span class="svg-icon" id="faq-svg"
                                data-svg-icon="<?php echo e(asset('frontend/img/others/faq_shape02.svg')); ?>"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/home-three/sections/faq-area.blade.php ENDPATH**/ ?>