<section class="categories-area-three fix section-pt-140 section-pb-110 categories__bg"
    data-background="<?php echo e(asset('frontend/img/bg/categories_bg.jpg')); ?>">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6 col-lg-8">
                <div class="section__title text-center mb-50">
                    <span class="sub-title"><?php echo e(__('Our Top Categories')); ?></span>
                    <h2 class="title bold"><?php echo e(__('Your Creative and Passionate Business Coach')); ?></h2>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $trendingCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-sm-6">
                    <div class="categories__item-three">
                        <a href="<?php echo e(route('courses', ['main_category' => $category->slug])); ?>">
                            <div class="icon">
                                <img src="<?php echo e(asset($category->icon)); ?>" alt="">
                            </div>
                            <span class="name"><?php echo e($category->translation->name); ?></span>
                            <span class="courses"><?php echo e($category->subCategories->sum('courses_count')); ?>

                                <?php echo e(__('Courses')); ?></span>
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="categories__shape-wrap">
        <img src="<?php echo e(asset('frontend/img/others/h7_categories_shape01.svg')); ?>" alt="shape" class="rotateme">
        <img src="<?php echo e(asset('frontend/img/others/h7_categories_shape02.svg')); ?>" alt="shape" data-aos="fade-down-left"
            data-aos-delay="400">
        <img src="<?php echo e(asset('frontend/img/others/h7_categories_shape03.svg')); ?>" alt="shape" class="alltuchtopdown">
        <img src="<?php echo e(asset('frontend/img/others/h7_categories_shape04.svg')); ?>" alt="shape" data-aos="fade-up-right"
            data-aos-delay="400">
    </div>
</section>
<?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/home-four/sections/category-area.blade.php ENDPATH**/ ?>