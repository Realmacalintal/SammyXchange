<?php $__env->startSection('meta_title', $seo_setting['home_page']['seo_title']); ?>
<?php $__env->startSection('meta_description', $seo_setting['home_page']['seo_description']); ?>
<?php $__env->startSection('meta_keywords', ''); ?>

<?php $__env->startSection('contents'); ?>
    <?php if($sectionSetting?->hero_section): ?>
        <!-- banner-area -->
        <?php echo $__env->make('frontend.home-four.sections.banner-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- banner-area-end -->
    <?php endif; ?>
    <?php if($sectionSetting?->our_features_section): ?>
        <!-- features-area -->
        <?php echo $__env->make('frontend.home-four.sections.features-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- features-area-end -->
    <?php endif; ?>
    <?php if($sectionSetting?->featured_course_section): ?>
        <!-- course-area -->
        <?php echo $__env->make('frontend.home-four.sections.course-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- course-area-end -->
    <?php endif; ?>

    <?php if($sectionSetting?->banner_section): ?>
        <!-- instructor-area-two -->
        <?php echo $__env->make('frontend.home-four.sections.join-us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- instructor-area-two-end -->
    <?php endif; ?>

    <?php if($sectionSetting?->about_section): ?>
        <!-- about-area -->
        <?php echo $__env->make('frontend.home-four.sections.about-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- about-area-end -->
    <?php endif; ?>

    <?php if($sectionSetting?->top_category_section): ?>
        <!-- categories-area -->
        <?php echo $__env->make('frontend.home-four.sections.category-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- categories-area-end -->
    <?php endif; ?>

    <?php if($sectionSetting?->featured_instructor_section): ?>
        <!-- instructor-area -->
        <?php echo $__env->make('frontend.home-four.sections.instructor-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- instructor-area-end -->
    <?php endif; ?>
    <?php if($sectionSetting?->testimonial_section): ?>
        <!-- testimonial-area -->
        <?php echo $__env->make('frontend.home-four.sections.testimonial-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- testimonial-area-end -->
    <?php endif; ?>

    <?php if($sectionSetting?->brands_section): ?>
        <!-- brand-area -->
        <?php echo $__env->make('frontend.home-four.sections.brand-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- brand-area-end -->
    <?php endif; ?>
    <?php if($sectionSetting?->news_letter_section): ?>
        <!-- newsletter-area -->
        <?php echo $__env->make('frontend.home-four.sections.newsletter-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- newsletter-area-end -->
    <?php endif; ?>

    <?php if($sectionSetting?->latest_blog_section): ?>
        <!-- blog-area -->
        <?php echo $__env->make('frontend.home-four.sections.blog-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- blog-area-end -->
    <?php endif; ?>
    <?php if($sectionSetting?->banner_section): ?>
        <!-- instructor-area-two -->
        <section class="newsletter__area-two">
            <div class="container">
                <div class="newsletter__inner-wrap">
                    <h2 class="title"><?php echo e(__('Join our teaching team and inspire the next generation!')); ?>.</h2>
                    <div class="newsletter__btn">
                        <a href="<?php echo e(route('register')); ?>" class="btn arrow-btn btn-two"><?php echo e(__('Get Started Now')); ?> <img src="<?php echo e(asset('frontend/img/icons/right_arrow.svg')); ?>" alt="" class="injectable"></a>
                    </div>
                    <img src="<?php echo e(asset('frontend/img/others/h7_newsletter_shape01.svg')); ?>" alt="shape" data-aos="fade-down-right" data-aos-delay="400" class="shape shape-one">
                    <img src="<?php echo e(asset('frontend/img/others/h7_newsletter_shape02.svg')); ?>" alt="shape" class="shape shape-two rotateme">
                </div>
            </div>
        </section>
        <!-- instructor-area-two-end -->
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/home-four/index.blade.php ENDPATH**/ ?>