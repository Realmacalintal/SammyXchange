<section class="newsletter__area">
  <div class="container">
      <div class="row align-items-center">
          <div class="col-lg-4">
              <div class="newsletter__img-wrap">
                  <img src="<?php echo e(asset($newsletterSection?->image)); ?>" alt="img">
                  <img src="<?php echo e(asset('frontend/img/others/newsletter_shape01.png')); ?>" alt="img" data-aos="fade-up"
                      data-aos-delay="400">
                  <img src="<?php echo e(asset('frontend/img/others/newsletter_shape02.png')); ?>" alt="img" class="alltuchtopdown">
              </div>
          </div>
          <div class="col-lg-8">
              <div class="newsletter__content">
                  <h2 class="title"><b><?php echo e(__('Want to stay informed about')); ?></b> <br> <b><?php echo e(__('new courses and study')); ?>?</b></h2>
                  <div class="newsletter__form">
                      <form action="" method="post" class="newsletter">
                        <?php echo csrf_field(); ?>
                          <input type="email" placeholder="<?php echo e(__('Type your email')); ?>" name="email">
                          <button type="submit" class="btn"><?php echo e(__('Subscribe Now')); ?></button>
                      </form>
                  </div>
              </div>
          </div>
      </div>
  </div>
  <div class="newsletter__shape">
      <img src="<?php echo e(asset('frontend/img/others/newsletter_shape03.png')); ?>" alt="img" data-aos="fade-left"
          data-aos-delay="400">
  </div>
</section><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/home-one/sections/newsletter-area.blade.php ENDPATH**/ ?>