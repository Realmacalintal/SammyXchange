<div class="tab-pane fade" id="cookie_consent_tab" role="tabpanel">
    <form action="<?php echo e(route('admin.update-cookie-consent')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for=""><?php echo e(__('Status')); ?></label>
                    <select name="cookie_status" id="" class="form-control">
                        <option <?php echo e($setting->cookie_status == 'active' ? 'selected' : ''); ?> value="active">
                            <?php echo e(__('Enable')); ?></option>
                        <option <?php echo e($setting->cookie_status == 'inactive' ? 'selected' : ''); ?> value="inactive">
                            <?php echo e(__('Disable')); ?></option>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for=""><?php echo e(__('Border')); ?></label>
                    <select name="border" id="" class="form-control">
                        <option <?php echo e($setting->border == 'none' ? 'selected' : ''); ?> value="none">
                            <?php echo e(__('None')); ?></option>
                        <option <?php echo e($setting->border == 'thin' ? 'selected' : ''); ?> value="thin">
                            <?php echo e(__('Thin')); ?></option>
                        <option <?php echo e($setting->border == 'normal' ? 'selected' : ''); ?> value="normal">
                            <?php echo e(__('Normal')); ?></option>
                        <option <?php echo e($setting->border == 'thick' ? 'selected' : ''); ?> value="thick">
                            <?php echo e(__('Thick')); ?></option>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for=""><?php echo e(__('Corner')); ?></label>
                    <select name="corners" id="" class="form-control">
                        <option <?php echo e($setting->corners == 'none' ? 'selected' : ''); ?> value="none">
                            <?php echo e(__('None')); ?></option>
                        <option <?php echo e($setting->corners == 'small' ? 'selected' : ''); ?> value="small">
                            <?php echo e(__('Small')); ?></option>
                        <option <?php echo e($setting->corners == 'normal' ? 'selected' : ''); ?> value="normal">
                            <?php echo e(__('Normall')); ?></option>
                        <option <?php echo e($setting->corners == 'large' ? 'selected' : ''); ?> value="large">
                            <?php echo e(__('Large')); ?></option>
                    </select>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="bg_color"><?php echo e(__('Background Color')); ?></label>
                    <input class="form-control" type="color" name="background_color" id="bg_color"
                        value="<?php echo e($setting->background_color); ?>">

                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="text_color"><?php echo e(__('Text Color')); ?></label>
                    <input class="form-control" type="color" name="text_color" id="text_color"
                        value="<?php echo e($setting->text_color); ?>">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="border_color"><?php echo e(__('Border Color')); ?></label>
                    <input class="form-control" type="color" name="border_color" id="border_color"
                        value="<?php echo e($setting->border_color); ?>">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="btn_bg_color"><?php echo e(__('Button Color')); ?></label>
                    <input class="form-control" type="color" name="btn_bg_color" id="btn_bg_color"
                        value="<?php echo e($setting->btn_bg_color); ?>">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="btn_text_color"><?php echo e(__('Button Text Color')); ?></label>
                    <input class="form-control" type="color" name="btn_text_color" id="btn_text_color"
                        value="<?php echo e($setting->btn_text_color); ?>">
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label for=""><?php echo e(__('Link')); ?></label>
                    <input type="text" name="link" value="<?php echo e(@$setting->link); ?>" class="form-control">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for=""><?php echo e(__('Link Text')); ?></label>
                    <input type="text" name="link_text" value="<?php echo e($setting->link_text); ?>" class="form-control">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for=""><?php echo e(__('Button Text')); ?></label>
                    <input type="text" name="btn_text" value="<?php echo e($setting->btn_text); ?>" class="form-control">
                </div>
            </div>

        </div>
        <div class="form-group">
            <label for="cookie_text"><?php echo e(__('Message')); ?></label>
            <textarea class="form-control text-area-5" name="message" id="cookie_text" cols="30" rows="5"><?php echo e($setting->message); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
    </form>
</div>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/GlobalSetting\resources/views/settings/sections/cookie.blade.php ENDPATH**/ ?>