<?php $__env->startSection('content'); ?>
    <div class="text-center card">
        <div class="card-header d-flex justify-content-between">
            <p>Setup Complete</p>
            <a class="btn btn-outline-primary" href="<?php echo e(route('setup.smtp')); ?>">&laquo; Back</a>
        </div>
        <div class="card-body">
            <h3 class="py-5 text-success">Congratulations! Installation is complete.</h3>
            <div class="d-flex justify-content-center">
                <form action="<?php echo e(route('website.completed', 'admin')); ?>" method="GET" class="p-2">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-primary">Visit Dashboard</button>
                </form>
                <form action="<?php echo e(route('website.completed', 'home')); ?>" method="GET" class="p-2">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-success">Visit Website</button>
                </form>
            </div>
        </div>
        <div class="card-footer">
            <p>For script support, contact us at <a href="https://websolutionus.com/page/support"
                target="_blank" rel="noopener noreferrer">@websolutionus</a>. We're here to help. Thank you!</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('installer::app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\skillgro\main_files\Modules/Installer\resources/views/complete.blade.php ENDPATH**/ ?>