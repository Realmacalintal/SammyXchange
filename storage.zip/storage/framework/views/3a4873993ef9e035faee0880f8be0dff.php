<?php $__empty_1 = true; $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="video_qna_list_item">

    <div class="img">
        <img src="<?php echo e(asset($question->user->image)); ?>" alt="img">
    </div>
    <div class="text">
        <div class="d-flex justify-content-between">
            <a class="qna_title question-item " data-question-id="<?php echo e($question->id); ?>" href="javascript:;"><?php echo e($question->question_title); ?></a>
            <?php if($question->user_id == auth()->user()->id): ?>
            <a href="<?php echo e(route('student.destroy-question', $question->id)); ?>" class="text-danger delete-item"><i class="fas fa-trash-alt"></i></a>
            <?php endif; ?>
        </div>
        <?php echo clean(replaceImageSources($question->question_description)); ?>

        <ul>
            <li><a href="#"><?php echo e($question->user->name); ?></a></li>
            <li><?php echo e(formatDate($question->created_at, 'd M, Y : H:i')); ?></li>
        </ul>
        <span><?php echo e($question->replies_count); ?> <i class="fas fa-comment"></i></span>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<p class="text-center p-4"><?php echo e(__('No questions yet!')); ?></p>
<?php endif; ?><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/pages/learning-player/partials/question-card.blade.php ENDPATH**/ ?>