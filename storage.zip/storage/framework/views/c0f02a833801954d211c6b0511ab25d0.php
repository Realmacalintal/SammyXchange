<section class="testimonial__area section-py-120">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-5">
                <div class="section__title text-center mb-50">
                    <span class="sub-title"><?php echo e(__('Our Testimonials')); ?></span>
                    <h2 class="title"><?php echo e(__('What Students Think and Say About Us')); ?></h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="testimonial__item-wrap">
                    <div class="swiper-container testimonial-swiper-active">
                        <div class="swiper-wrapper">
                            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <div class="testimonial__item">
                                        <div class="testimonial__item-top">
                                            <div class="testimonial__author">
                                                <div class="testimonial__author-thumb">
                                                    <img src="<?php echo e(asset($testimonial->image)); ?>" alt="img">
                                                </div>
                                                <div class="testimonial__author-content">
                                                    <div class="rating">
                                                        <?php for($i = 0; $i < $testimonial->rating; $i++): ?>
                                                            <i class="fas fa-star"></i>
                                                        <?php endfor; ?>
                                                    </div>
                                                    <h2 class="title"><?php echo e($testimonial->translation->name); ?></h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="testimonial__content">
                                            <p>“ <?php echo e($testimonial->translation->comment); ?> ”</p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="testimonial__nav">
                        <button class="testimonial-button-prev"><i class="flaticon-arrow-right"></i></button>
                        <button class="testimonial-button-next"><i class="flaticon-arrow-right"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/home-three/sections/testimonial-area.blade.php ENDPATH**/ ?>