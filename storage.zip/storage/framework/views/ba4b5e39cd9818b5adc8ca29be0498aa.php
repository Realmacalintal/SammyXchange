<li class="menu-header"><?php echo e(__('Settings')); ?></li>
<li class="<?php echo e(Route::is('admin.general-setting') ? 'active' : ''); ?>"><a class="nav-link"
        href="<?php echo e(route('admin.general-setting')); ?>"><i class="fas fa-cog"></i>
        <span><?php echo e(__('General Settings')); ?></span></a></li>

<li class="<?php echo e(Route::is('admin.commission-setting') ? 'active' : ''); ?>"><a class="nav-link"
        href="<?php echo e(route('admin.commission-setting')); ?>"><i class="fas fa-money-bill"></i>
        <span><?php echo e(__('Commission')); ?></span></a></li>

<li class="<?php echo e(Route::is('admin.crediential-setting') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('admin.crediential-setting')); ?>"><i class="fas fa-key"></i>
        <span><?php echo e(__('Credential Settings')); ?></span>
    </a>
</li>
<li class="<?php echo e(Route::is('admin.marketing-setting') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('admin.marketing-setting')); ?>"><i class="fas fa-ad"></i>
        <span><?php echo e(__('Marketing Settings')); ?></span>
    </a>
</li>

<li class="<?php echo e(Route::is('admin.email-configuration') || Route::is('admin.edit-email-template') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('admin.email-configuration')); ?>"><i class="fas fa-envelope"></i>
        <span><?php echo e(__('Email Configuration')); ?></span>
    </a>
</li>

<?php if(Module::isEnabled('Language') && checkAdminHasPermission('language.view')): ?>
    <?php echo $__env->make('language::sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<li class="<?php echo e(Route::is('admin.seo-setting') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('admin.seo-setting')); ?>"><i class="fas fa-search"></i>
        <span><?php echo e(__('SEO Setup')); ?></span>
    </a>
</li>
<li class="menu-header"><?php echo e(__('Extra Settings')); ?></li>
<li class="nav-item dropdown <?php echo e(isRoute('admin.custom-code', 'active')); ?>">
    <a href="javascript:;" class="nav-link has-dropdown">
        <i class="fas fa-code"></i><span><?php echo e(__('Custom Code')); ?></span>
    </a>
    <ul class="dropdown-menu">
        <li class="<?php echo e((request()->routeIs('admin.custom-code') && request('type') == 'css') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.custom-code','css')); ?>">
                <?php echo e(__('CSS')); ?>

            </a>
        </li>
        <li class="<?php echo e((request()->routeIs('admin.custom-code') && request('type') == 'js') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.custom-code','js')); ?>">
                <?php echo e(__('JS')); ?>

            </a>
        </li>
    </ul>
</li>

<li class="<?php echo e(Route::is('admin.cache-clear') ? 'active' : ''); ?>"><a class="nav-link"
        href="<?php echo e(route('admin.cache-clear')); ?>"><i class="fas fa-sync"></i>
        <span><?php echo e(__('Clear cache')); ?></span>
    </a></li>

<li class="<?php echo e(Route::is('admin.database-clear') ? 'active' : ''); ?>"><a class="nav-link"
        href="<?php echo e(route('admin.database-clear')); ?>"><i class="fas fa-database"></i>
        <span><?php echo e(__('Database Clear')); ?></span></a></li>

<li class="<?php echo e(Route::is('admin.system-update.index') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('admin.system-update.index')); ?>"><i class="fas fa-arrow-circle-up"></i>
        <span><?php echo e(__('System Update')); ?></span>
    </a>
</li>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/GlobalSetting\resources/views/sidebar.blade.php ENDPATH**/ ?>