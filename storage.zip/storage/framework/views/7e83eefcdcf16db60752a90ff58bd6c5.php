<div class="tab-pane fade" id="social_login_tab" role="tabpanel">
    <form action="<?php echo e(route('admin.update-social-login')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <div class="form-group">
                <label for=""><?php echo e(__('Google Status')); ?></label>
                <select name="google_login_status" id="tawk_allow" class="form-control">
                    <option <?php echo e($setting->google_login_status == 'active' ? 'selected' : ''); ?> value="active">
                        <?php echo e(__('Enable')); ?></option>
                    <option <?php echo e($setting->google_login_status == 'inactive' ? 'selected' : ''); ?> value="inactive">
                        <?php echo e(__('Disable')); ?></option>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label for=""><?php echo e(__('Google Client Id')); ?></label>
            <?php if(env('APP_MODE') == 'DEMO'): ?>
                <input type="text" value="GMAIL-ID-34343-DEMO-CLIENT" class="form-control" name="gmail_client_id">
            <?php else: ?>
                <input type="text" value="<?php echo e($setting->gmail_client_id); ?>" class="form-control"
                    name="gmail_client_id">
            <?php endif; ?>

        </div>

        <div class="form-group">
            <label for=""><?php echo e(__('Google Secret Id')); ?></label>
            <?php if(env('APP_MODE') == 'DEMO'): ?>
                <input type="text" value="GMAIL-ID-343943-TEST-SECRET" class="form-control" name="gmail_secret_id">
            <?php else: ?>
                <input type="text" value="<?php echo e($setting->gmail_secret_id); ?>" class="form-control"
                    name="gmail_secret_id">
            <?php endif; ?>

        </div>
        <button class="btn btn-primary"><?php echo e(__('Update')); ?></button>
    </form>
    <div class="form-group mt-3">
        <label><?php echo e(__('Callback url ')); ?> <span data-toggle="tooltip"
            data-placement="top" class="fa fa-info-circle text--primary"
            title="<?php echo e(__('Copy the Gmail login URL and paste it wherever you need to use it.')); ?>"></span></label>
        <div class="input-group">
            <input type="text" value="<?php echo e(url('/auth/google/callback')); ?>" id="gmail_redirect_url" class="form-control" readonly>
          <div class="input-group-append">
            <div class="input-group-text">
                <span id="copyButton"  data-toggle="tooltip" title="<?php echo e(__('Copy the Gmail login URL and paste it wherever you need to use it.')); ?>"><i class="fas fa-copy"></i></span>
            </div>
          </div>
        </div>
      </div>
</div>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/GlobalSetting\resources/views/credientials/sections/social-login.blade.php ENDPATH**/ ?>