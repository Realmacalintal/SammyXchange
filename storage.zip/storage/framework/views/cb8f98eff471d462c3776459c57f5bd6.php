<section class="fact__area-three fact__bg" data-background="<?php echo e(asset('frontend/img/bg/fact_bg.jpg')); ?>">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-5">
                <div class="fact__content-wrap">
                    <h2 class="title"><?php echo clean(processText($counter?->translation?->section_title)); ?></h2>
                    <p><?php echo e($counter?->translation?->description); ?></p>
                    <a href="<?php echo e(route('contact.index')); ?>" class="btn arrow-btn"><?php echo e(__('Take a Tour')); ?> <img src="<?php echo e(asset('frontend/img/icons/right_arrow.svg')); ?>" alt="" class="injectable"></a>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="fact__item-wrap-two">
                    <div class="row justify-content-center">
                        <div class="col-md-4 col-sm-6">
                            <div class="fact__item fact__item-two">
                                <h2 class="count"><span class="odometer" data-count="<?php echo e($counter?->total_student_count); ?>"></span>+</h2>
                                <p><?php echo e(__('Active Students')); ?></p>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="fact__item fact__item-two">
                                <h2 class="count"><span class="odometer" data-count="<?php echo e($counter?->total_instructor_count); ?>"></span>+</h2>
                                <p><?php echo e(__('Best Professors')); ?></p>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="fact__item fact__item-two">
                                <h2 class="count"><span class="odometer" data-count="<?php echo e($counter?->total_courses_count); ?>"></span>+</h2>
                                <p><?php echo e(__('Faculty Courses')); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="fact__shape-wrap">
        <img src="<?php echo e(asset('frontend/img/others/h3_fact_shape01.svg')); ?>" alt="shape" class="alltuchtopdown">
        <img src="<?php echo e(asset('frontend/img/others/h3_fact_shape02.svg')); ?>" alt="shape" class="rotateme">
    </div>
</section><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/home-three/sections/fact-area.blade.php ENDPATH**/ ?>