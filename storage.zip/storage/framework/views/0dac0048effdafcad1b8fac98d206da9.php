<section class="fact__area">
  <div class="container">
      <div class="fact__inner-wrap">
          <div class="row">
              <div class="col-lg-3 col-sm-6">
                  <div class="fact__item">
                      <h2 class="count"><span class="odometer" data-count="<?php echo e($counter?->total_student_count); ?>"></span>+</h2>
                      <p><?php echo e(__('Active Students')); ?></p>
                  </div>
              </div>
              <div class="col-lg-3 col-sm-6">
                  <div class="fact__item">
                      <h2 class="count"><span class="odometer" data-count="<?php echo e($counter?->total_instructor_count); ?>"></span>+</h2>
                      <p><?php echo e(__('Faculty Courses')); ?></p>
                  </div>
              </div>
              <div class="col-lg-3 col-sm-6">
                  <div class="fact__item">
                      <h2 class="count"><span class="odometer" data-count="<?php echo e($counter?->total_courses_count); ?>"></span>+</h2>
                      <p><?php echo e(__('Best Professors')); ?></p>
                  </div>
              </div>
              <div class="col-lg-3 col-sm-6">
                  <div class="fact__item">
                      <h2 class="count"><span class="odometer" data-count="<?php echo e($counter?->total_awards_count); ?>"></span>+</h2>
                      <p><?php echo e(__('Award Achieved')); ?></p>
                  </div>
              </div>
          </div>
      </div>
  </div>
</section><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/home-one/sections/fact-area.blade.php ENDPATH**/ ?>