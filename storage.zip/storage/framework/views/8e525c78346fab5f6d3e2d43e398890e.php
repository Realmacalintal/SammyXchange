<?php $__env->startSection('title'); ?>
    <title><?php echo e(__('Login')); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="container login-wrapper">
            <div class="col-md-12 col-lg-4">
                <div class="login-brand">
                    <a href="<?php echo e(route('home')); ?>">
                        <img src="<?php echo e(asset($setting?->logo)); ?>" alt="<?php echo e($setting?->app_name); ?>" width="220">
                    </a>
                </div>
                <div class="card card-primary">
                    <div class="card-header">
                        <h4><?php echo e(__('Welcome to Admin Login')); ?></h4>
                    </div>

                    <div class="card-body">
                        <form novalidate="" id="adminLoginForm" action="<?php echo e(route('admin.store-login')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="email"><?php echo e(__('Email')); ?></label>

                                <input id="email exampleInputEmail" type="email" class="form-control" name="email"
                                    tabindex="1" autofocus value="<?php echo e(old('email')); ?>">
                            </div>

                            <div class="form-group">
                                <div class="d-block">
                                    <label for="password" class="control-label"><?php echo e(__('Password')); ?></label>
                                    <div class="float-right">
                                        <a href="<?php echo e(route('admin.password.request')); ?>" class="text-small">
                                            <?php echo e(__('Forgot Password?')); ?>

                                        </a>
                                    </div>
                                </div>
                                <input id="password exampleInputPassword" type="password" class="form-control"
                                        name="password" tabindex="2">
                            </div>

                            <div class="form-group">
                                <button id="adminLoginBtn" type="submit" class="btn btn-primary btn-lg btn-block"
                                    tabindex="4">
                                    <?php echo e(__('Login')); ?>

                                </button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>