<div class="tab-pane fade" id="logo_favicon_tab" role="tabpanel">
    <form action="<?php echo e(route('admin.update-logo-favicon')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="row justify-content-center">

        <div class="form-group col-lg-4">
            <label><?php echo e(__('Logo')); ?> <code><?php echo e(__('Recommended')); ?>:(155px x 40px)</code><span class="text-danger"></span></label>
            <div id="image-preview-1" class="image-preview">
                <label for="image-upload-1" id="image-label-1"><?php echo e(__('Image')); ?></label>
                <input type="file" name="logo" id="image-upload-1">
            </div>
            <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group col-lg-4">
            <label><?php echo e(__('Favicon')); ?><span class="text-danger"></span></label>
            <div id="image-preview-2" class="image-preview">
                <label for="image-upload-2" id="image-label-2"><?php echo e(__('Image')); ?></label>
                <input type="file" name="favicon" id="image-upload-2">
            </div>
            <?php $__errorArgs = ['favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group col-lg-4">
            <label><?php echo e(__('Preloader')); ?><span class="text-danger"></span></label>
            <div id="image-preview-3" class="image-preview">
                <label for="image-upload-3" id="image-label-3"><?php echo e(__('Image')); ?></label>
                <input type="file" name="preloader" id="image-upload-3">
            </div>
            <?php $__errorArgs = ['preloader'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        </div>

       
        <button class="btn btn-primary"><?php echo e(__('Update')); ?></button>
    </form>
</div>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/js/jquery.uploadPreview.min.js')); ?>"></script>
    <script>
        "use strict";
        $.uploadPreview({
            input_field: "#image-upload-1",
            preview_box: "#image-preview-1",
            label_field: "#image-label-1",
            label_default: "<?php echo e(__('Choose Image')); ?>",
            label_selected: "<?php echo e(__('Change Image')); ?>",
            no_label: false,
            success_callback: null
        });
        $('#image-preview-1').css({
            'background-image': 'url(<?php echo e(!empty($setting->logo) ? asset($setting->logo) : ''); ?>)',
            'background-size': 'contain',
            'background-position': 'center',
            'background-repeat': 'no-repeat'
        });

        $.uploadPreview({
            input_field: "#image-upload-2",
            preview_box: "#image-preview-2",
            label_field: "#image-label-2",
            label_default: "<?php echo e(__('Choose Image')); ?>",
            label_selected: "<?php echo e(__('Change Image')); ?>",
            no_label: false,
            success_callback: null
        });
        $('#image-preview-2').css({
            'background-image': 'url(<?php echo e(asset(@$setting->favicon)); ?>)',
            'background-size': 'contain',
            'background-position': 'center',
            'background-repeat': 'no-repeat'
        });

        $.uploadPreview({
            input_field: "#image-upload-3",
            preview_box: "#image-preview-3",
            label_field: "#image-label-3",
            label_default: "<?php echo e(__('Choose Image')); ?>",
            label_selected: "<?php echo e(__('Change Image')); ?>",
            no_label: false,
            success_callback: null
        });
        $('#image-preview-3').css({
            'background-image': 'url(<?php echo e(asset(@$setting->preloader)); ?>)',
            'background-size': 'contain',
            'background-position': 'center',
            'background-repeat': 'no-repeat'
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/GlobalSetting\resources/views/settings/sections/logo-favicon.blade.php ENDPATH**/ ?>