<script src="<?php echo e(asset('global/js/jquery-3.7.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/jquery.nicescroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/stisla.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/scripts.js')); ?>?v=<?php echo e($setting?->version); ?>"></script>
<script src="<?php echo e(asset('backend/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/tagify.js')); ?>"></script>
<script src="<?php echo e(asset('global/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/bootstrap4-toggle.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/fontawesome-iconpicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/bootstrap-datepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/clockpicker/dist/bootstrap-clockpicker.js')); ?>"></script>
<script src="<?php echo e(asset('backend/datetimepicker/jquery.datetimepicker.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/iziToast.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/modules-toastr.js')); ?>?v=<?php echo e($setting?->version); ?>"></script>
<script src="<?php echo e(asset('backend/tinymce/js/tinymce/tinymce.min.js')); ?>"></script>
<script src="<?php echo e(asset('global/nice-select/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/default/backend.js')); ?>?v=<?php echo e($setting?->version); ?>"></script>
<script src="<?php echo e(asset('backend/js/custom.js')); ?>?v=<?php echo e($setting?->version); ?>"></script>

<!-- File Manager js-->
<script src="<?php echo e(url('/vendor/laravel-filemanager/js/stand-alone-button.js')); ?>"></script>

<script>
    $('.file-manager').filemanager('file', {prefix: '<?php echo e(url("/laravel-filemanager")); ?>'});
    $('.file-manager-image').filemanager('image', {prefix: '<?php echo e(url("/laravel-filemanager")); ?>'});
</script>

<script>
    <?php $__sessionArgs = ['messege'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
    var type = "<?php echo e(Session::get('alert-type', 'info')); ?>"
    switch (type) {
        case 'info':
            toastr.info("<?php echo e($value); ?>");
            break;
        case 'success':
            toastr.success("<?php echo e($value); ?>");
            break;
        case 'warning':
            toastr.warning("<?php echo e($value); ?>");
            break;
        case 'error':
            toastr.error("<?php echo e($value); ?>");
            break;
    }
    <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

    $('.datepicker').datepicker({
        format: 'yyyy-mm-dd',
        orientation: "bottom auto"
    });
</script>

<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script>
            toastr.error('<?php echo e($error); ?>');
        </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/admin/partials/javascripts.blade.php ENDPATH**/ ?>