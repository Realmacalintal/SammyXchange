<li class="<?php echo e(Route::is('admin.currency.*') ? 'active' : ''); ?>"><a class="nav-link"
        href="<?php echo e(route('admin.currency.index')); ?>"><i class="fas fa-coins"></i>
        <span><?php echo e(__('Multi Currency')); ?></span></a></li>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/Currency\resources/views/sidebar.blade.php ENDPATH**/ ?>