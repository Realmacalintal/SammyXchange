<div class="brand-area-three section-pb-120">
    <div class="container">
        <div class="swiper-container brand-swiper-active">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <div class="brand__item-two">
                            <img src="<?php echo e(asset($brand->image)); ?>" alt="img">
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/home-four/sections/brand-area.blade.php ENDPATH**/ ?>