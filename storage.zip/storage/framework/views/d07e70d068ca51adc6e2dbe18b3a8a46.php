<li class="nav-item">
    <a class="nav-link active show" id="google-data-layer-tab" data-toggle="tab" href="#google_data_layer_tab" role="tab"
        aria-controls="google-data-layer" aria-selected="false"><?php echo e(__('Google tag manager data layer')); ?></a>
</li>


<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/GlobalSetting\resources/views/marketings/tabs/navbar.blade.php ENDPATH**/ ?>