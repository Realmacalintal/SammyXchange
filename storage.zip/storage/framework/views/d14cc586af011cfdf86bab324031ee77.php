<div class="tab-pane fade" id="tawk_chat_tab" role="tabpanel">
    <form action="<?php echo e(route('admin.update-tawk-chat')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for=""><?php echo e(__('Status')); ?></label>
            <select name="tawk_status" id="tawk_status" class="form-control">
                <option <?php echo e($setting->tawk_status == 'active' ? 'selected' : ''); ?> value="active"><?php echo e(__('Enable')); ?>

                </option>
                <option <?php echo e($setting->tawk_status == 'inactive' ? 'selected' : ''); ?> value="inactive"><?php echo e(__('Disable')); ?>

                </option>
            </select>
        </div>

        <div class="form-group">
            <label for=""><?php echo e(__('Tawk Chat Link')); ?></label>
            <?php if(env('APP_MODE') == 'DEMO'): ?>
                <input type="text" class="form-control" name="tawk_chat_link"
                    value="https://www.tawk.to/demo-link/34893439">
            <?php else: ?>
                <input type="text" class="form-control" name="tawk_chat_link" value="<?php echo e($setting->tawk_chat_link); ?>">
            <?php endif; ?>

        </div>

        <button class="btn btn-primary"><?php echo e(__('Update')); ?></button>
    </form>
</div>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/GlobalSetting\resources/views/credientials/sections/tawk-chat.blade.php ENDPATH**/ ?>