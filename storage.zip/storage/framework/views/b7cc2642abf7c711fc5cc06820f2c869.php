<div class="tab-pane fade active show" id="google_recaptcha_tab" role="tabpanel">
    <form action="<?php echo e(route('admin.update-google-captcha')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for=""><?php echo e(__('Status')); ?></label>
            <select name="recaptcha_status" id="recaptcha_status" class="form-control">
                <option <?php echo e($setting->recaptcha_status == 'active' ? 'selected' : ''); ?> value="active">
                    <?php echo e(__('Enable')); ?></option>
                <option <?php echo e($setting->recaptcha_status == 'inactive' ? 'selected' : ''); ?> value="inactive">
                    <?php echo e(__('Disable')); ?></option>
            </select>
        </div>

        <div class="form-group">
            <label for=""><?php echo e(__('Captcha Site Key')); ?></label>
            <?php if(env('APP_MODE') == 'DEMO'): ?>
                <input type="text" class="form-control" name="recaptcha_site_key" value="ZXN39334XKF-SITE-KEY-TEST">
            <?php else: ?>
                <input type="text" class="form-control" name="recaptcha_site_key"
                    value="<?php echo e($setting->recaptcha_site_key); ?>">
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for=""><?php echo e(__('Captcha Secret Key')); ?></label>
            <?php if(env('APP_MODE') == 'DEMO'): ?>
                <input type="text" class="form-control" name="recaptcha_secret_key"
                    value="ZXN39334XKF-SECRET-KEY-TEST">
            <?php else: ?>
                <input type="text" class="form-control" name="recaptcha_secret_key"
                    value="<?php echo e($setting->recaptcha_secret_key); ?>">
            <?php endif; ?>
        </div>

        <button class="btn btn-primary"><?php echo e(__('Update')); ?></button>

    </form>
</div>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/GlobalSetting\resources/views/credientials/sections/google-recaptcha.blade.php ENDPATH**/ ?>