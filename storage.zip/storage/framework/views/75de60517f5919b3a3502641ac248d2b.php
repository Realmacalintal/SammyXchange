<section class="about-area-four section-pb-120">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-lg-5 col-md-9">
                <div class="about__images-four">
                    <img src="<?php echo e(manageAssetImage('uploads/homepages/university/about_img.jpg', $aboutSection?->image)); ?>"
                        alt="">
                    <?php if($hero?->translation?->total_student): ?>
                        <div class="about__enrolled" data-aos="fade-up" data-aos-delay="400">
                            <p class="title"><span><?php echo e($hero->translation?->total_student); ?></span>
                                <?php echo e(__('Enrolled Students')); ?></p>
                            <img src="<?php echo e(asset($hero->enroll_students_image)); ?>" alt="img">
                        </div>
                    <?php endif; ?>
                    <?php if($aboutSection?->video_url): ?>
                        <div class="about__video" data-aos="fade-left" data-aos-delay="400">
                            <a href="<?php echo e($aboutSection?->video_url); ?>" class="play-btn popup-video"><i
                                    class="fas fa-play"></i> <?php echo e(__('Watch our')); ?> <br> <?php echo e(__('Video')); ?></a>
                        </div>
                    <?php endif; ?>
                    <?php if($aboutSection?->year_experience): ?>
                        <div class="about__year-wrap">
                            <h2 class="count"><?php echo e($aboutSection?->year_experience); ?></h2>
                            <h5 class="title"><?php echo e(__('year')); ?> <br> <?php echo e(__('of Institutes')); ?></h5>
                        </div>
                    <?php endif; ?>
                    <div class="shape">
                        <img src="<?php echo e(asset('frontend/img/others/h3_about_shape01.svg')); ?>" alt="shape"
                            data-aos="fade-right" data-aos-delay="200" class="alltuchtopdown">
                        <img src="<?php echo e(asset('frontend/img/others/h3_about_shape02.svg')); ?>" alt="shape"
                            data-aos="fade-right" data-aos-delay="200">
                    </div>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="about__content-four">
                    <div class="section__title mb-15">
                        <span class="sub-title"><?php echo e(__('About Campus history')); ?></span>
                        <h2 class="title"><?php echo clean(processText($aboutSection?->translation?->title)); ?></h2>
                    </div>
                    <?php echo clean(processText($aboutSection?->translation?->description)); ?>

                    <a href="<?php echo e($aboutSection?->button_url); ?>"
                        class="btn arrow-btn"><?php echo e($aboutSection?->translation?->button_text); ?> <img
                            src="<?php echo e(asset('frontend/img/icons/right_arrow.svg')); ?>" alt=""
                            class="injectable"></a>
                    <img src="<?php echo e(asset('frontend/img/others/h3_about_shape03.svg')); ?>" alt="shape"
                        class="shape alltuchtopdown">
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/home-three/sections/about-area.blade.php ENDPATH**/ ?>