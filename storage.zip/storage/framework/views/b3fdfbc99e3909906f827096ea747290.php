<li class="nav-item">
    <a class="nav-link active show" id="general-tab" data-toggle="tab" href="#general_tab" role="tab"
        aria-controls="general" aria-selected="true"><?php echo e(__('General Setting')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" id="logo-favicon-tab" data-toggle="tab" href="#logo_favicon_tab" role="tab"
        aria-controls="logo-favicon" aria-selected="false"><?php echo e(__('Logo & Favicon')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" id="cookie-consent-tab" data-toggle="tab" href="#cookie_consent_tab" role="tab"
        aria-controls="cookie-consent" aria-selected="false"><?php echo e(__('Cookie Consent')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" id="breadcrump-tab" data-toggle="tab" href="#breadcrump_img_tab" role="tab"
        aria-controls="breadcrump" aria-selected="false"><?php echo e(__('Breadcrumb image')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" id="copyright-text" data-toggle="tab" href="#copyright_text_tab" role="tab"
        aria-controls="copyright" aria-selected="true"><?php echo e(__('Copyright Text')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" id="maintenance-tab" data-toggle="tab" href="#mmaintenance_mode_tab" role="tab"
        aria-controls="maintenance" aria-selected="false"><?php echo e(__('Maintenance Mode')); ?></a>
</li>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/GlobalSetting\resources/views/settings/tabs/navbar.blade.php ENDPATH**/ ?>