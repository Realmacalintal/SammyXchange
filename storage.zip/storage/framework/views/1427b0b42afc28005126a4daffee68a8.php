<?php
$currentUrl = url()->current();
$language_code = !empty(request('code')) ? request('code') : getSessionLanguage();
?>
<div>
    <div class="lang_list_top">
        <ul class="lang_list">
            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a id="<?php echo e(request('code') == $language->code ? 'selected-language' : ''); ?>"
                        href="<?php echo e(currectUrlWithQuery($language->code)); ?>"><i
                            class="fas <?php echo e(request('code') == $language->code || ($language->code == config('app.locale') && empty(request('code'))) ? 'fa-eye' : 'fa-edit'); ?>"></i>
                        <?php echo e($language->name); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <div class="mt-2 alert alert-danger" role="alert">
        <?php
            $current_language = $languages->where('code', $language_code)->first();
        ?>
        <p><?php echo e(__('Your editing mode')); ?> :
            <b><?php echo e($current_language?->name); ?></b>
        </p>
    </div>
</div>
<input type="hidden" id="language_code" value="<?php echo e($language_code); ?>">
<div id="hwpwrap">
    <div class="custom-wp-admin wp-admin wp-core-ui js   menu-max-depth-0 nav-menus-php auto-fold admin-bar">
        <div id="wpwrap">
            <div id="wpcontent">
                <div id="wpbody">
                    <div id="wpbody-content">

                        <div class="wrap">

                            <div class="manage-menus">
                                <form method="get" action="<?php echo e($currentUrl); ?>">
                                    <label for="menu" class="selected-menu"><?php echo e(__('select_menu_edit')); ?></label>
                                    <select name="menu">
                                        <option <?php echo e(request()->input('menu') == 0 ? 'selected="selected"' : ''); ?>

                                            value="0"><?php echo e(__('select_menu')); ?></option>
                                        <?php $__currentLoopData = $menulist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                                <?php echo e(request()->input('menu') == $val->id ? 'selected="selected"' : ''); ?>

                                                value="<?php echo e($val->id); ?>">
                                                <?php echo e(Str::replace('_', ' ', ucwords($val->getTranslation($language_code)?->name))); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="submit-btn">
                                        <input type="submit" class="btn btn-primary text-white"
                                            value="<?php echo e(__('choose')); ?>">
                                    </span>

                                </form>
                            </div>
                            <div id="nav-menus-frame">
                                <div class="row">
                                    <div class="col-xxl-3 col-lg-4">

                                        <?php if(request()->has('menu') && !empty(request()->input('menu'))): ?>
                                            <div id="menu-settings-column" class="metabox-holder">

                                                <div class="clear"></div>

                                                <form id="nav-menu-meta" action="" class="nav-menu-meta"
                                                    method="post" enctype="multipart/form-data">
                                                    <div id="side-sortables" class="accordion-container">
                                                        <ul class="outer-border">
                                                            <li class="control-section accordion-section open add-page"
                                                                id="add-page">
                                                                <h3 class="accordion-section-title hndle"
                                                                    tabindex="0">
                                                                    <?php echo e(__('add_link')); ?>

                                                                    <span
                                                                        class="screen-reader-text"><?php echo e(__('press_enter')); ?></span>
                                                                </h3>
                                                                <div class="accordion-section-content ">

                                                                    <p id="menu-item-url-wrap">
                                                                        <label class="howto"
                                                                            for="custom-menu-item-url">
                                                                            <span><?php echo e(__('Pages')); ?></span>&nbsp;&nbsp;&nbsp;
                                                                            <select id="existing-menu-select">
                                                                                <option><?php echo e(__('Custom Menu')); ?>

                                                                                </option>
                                                                                <?php $__currentLoopData = $defaultMenusList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option value="1"
                                                                                        data-label="<?php echo e($menu->name); ?>"
                                                                                        data-url="<?php echo e($menu->url); ?>">
                                                                                        <?php echo e($menu->name); ?></option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                        </label>
                                                                    </p>
                                                                    <div class="inside">
                                                                        <div class="customlinkdiv" id="customlinkdiv">
                                                                            <p id="menu-item-url-wrap">
                                                                                <label class="howto"
                                                                                    for="custom-menu-item-url">
                                                                                    <span><?php echo e(__('URL')); ?></span>&nbsp;&nbsp;&nbsp;
                                                                                    <input id="custom-menu-item-url"
                                                                                        name="url" type="text"
                                                                                        class="menu-item-textbox "
                                                                                        placeholder="<?php echo e(__('URL')); ?>">
                                                                                </label>
                                                                            </p>

                                                                            <p id="menu-item-name-wrap">
                                                                                <label class="howto"
                                                                                    for="custom-menu-item-name">
                                                                                    <span><?php echo e(__('label')); ?></span>&nbsp;
                                                                                    <input id="custom-menu-item-name"
                                                                                        name="label" type="text"
                                                                                        class="regular-text menu-item-textbox input-with-default-title"
                                                                                        title="<?php echo e(__('menu_label')); ?>">
                                                                                </label>
                                                                            </p>

                                                                            <?php if(!empty($roles)): ?>
                                                                                <p id="menu-item-role_id-wrap">
                                                                                    <label class="howto"
                                                                                        for="custom-menu-item-name">
                                                                                        <span><?php echo e(__('role')); ?></span>&nbsp;
                                                                                        <select
                                                                                            id="custom-menu-item-role"
                                                                                            name="role">
                                                                                            <option value="0">
                                                                                                <?php echo e(__('select_role')); ?>

                                                                                            </option>
                                                                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                <option
                                                                                                    value="<?php echo e($role->$role_pk); ?>">
                                                                                                    <?php echo e(ucfirst($role->$role_title_field)); ?>

                                                                                                </option>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                        </select>
                                                                                    </label>
                                                                                </p>
                                                                            <?php endif; ?>

                                                                            <p class="button-controls">

                                                                                <a href="#"
                                                                                    onclick="addcustommenu()"
                                                                                    class="btn btn-primary text-white submit-add-to-menu right"><?php echo e(__('add_menu_item')); ?></a>
                                                                                <span class="spinner"
                                                                                    id="spincustomu"></span>
                                                                            </p>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </form>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-xxl-9 col-lg-8">
                                        <div id="menu-management-liquid">
                                            <div id="menu-management">
                                                <form id="update-nav-menu" action="" method="post"
                                                    enctype="multipart/form-data">
                                                    <div class="menu-edit ">
                                                        <div id="nav-menu-header">
                                                            <div class="major-publishing-actions">
                                                                <label class="menu-name-label howto open-label"
                                                                    for="menu-name">
                                                                    <span><?php echo e(__('name')); ?></span>
                                                                    <input name="menu-name" id="menu-name"
                                                                        type="text" readonly
                                                                        class="menu-name regular-text menu-item-textbox"
                                                                        title="<?php echo e(__('enter_menu_name')); ?>"
                                                                        value="<?php if(isset($indmenu)): ?> <?php echo e(ucwords(Str::replace('_', ' ', $indmenu->getTranslation($language_code)?->name))); ?> <?php endif; ?>">
                                                                    <input type="hidden" id="idmenu"
                                                                        value="<?php if(isset($indmenu)): ?> <?php echo e($indmenu->id); ?> <?php endif; ?>" />
                                                                </label>

                                                                <?php if(request()->has('action')): ?>
                                                                    <div class="publishing-action">
                                                                        <a onclick="createnewmenu()" name="save_menu"
                                                                            id="save_menu_header"
                                                                            class="btn btn-primary text-white menu-save"><?php echo e(__('create_menu')); ?></a>
                                                                    </div>
                                                                <?php elseif(request()->has('menu')): ?>
                                                                    <div class="publishing-action">
                                                                        <a onclick="getmenus()" name="save_menu"
                                                                            id="save_menu_header"
                                                                            class="btn btn-primary text-white menu-save"><?php echo e(__('save_menu')); ?></a>
                                                                        <span class="spinner"
                                                                            id="spincustomu2"></span>
                                                                    </div>
                                                                <?php else: ?>
                                                                    <div class="publishing-action">
                                                                        <a onclick="createnewmenu()" name="save_menu"
                                                                            id="save_menu_header"
                                                                            class="btn btn-primary text-white menu-save"><?php echo e(__('create_menu')); ?></a>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div id="post-body">
                                                            <div id="post-body-content">

                                                                <?php if(request()->has('menu')): ?>
                                                                    <h3><?php echo e(__('menu_structure')); ?></h3>
                                                                    <div class="drag-instructions post-body-plain">
                                                                        <p>
                                                                            <?php echo e(__('menu_structure_text')); ?>

                                                                        </p>
                                                                    </div>
                                                                <?php else: ?>
                                                                    <h3><?php echo e(__('menu_creation')); ?></h3>
                                                                    <div class="drag-instructions post-body-plain">
                                                                        <p>
                                                                            <?php echo e(__('menu_creation_text')); ?>

                                                                        </p>
                                                                    </div>
                                                                <?php endif; ?>

                                                                <ul class="menu ui-sortable d-block"
                                                                    id="menu-to-edit">
                                                                    <?php if(isset($menus)): ?>
                                                                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <li id="menu-item-<?php echo e($m->id); ?>"
                                                                                class="menu-item menu-item-depth-<?php echo e($m->depth); ?> menu-item-page menu-item-edit-inactive pending">
                                                                                <dl class="menu-item-bar">
                                                                                    <dt class="menu-item-handle">
                                                                                        <span class="item-title"> <span
                                                                                                class="menu-item-title">
                                                                                                <span
                                                                                                    id="menutitletemp_<?php echo e($m->id); ?>"><?php echo e($m->getTranslation($language_code)->label); ?></span>
                                                                                                <span
                                                                                                    class="d-none">|<?php echo e($m->id); ?>|</span>
                                                                                            </span> <span
                                                                                                class="is-submenu"
                                                                                                style="<?php if($m->depth == 0): ?> display: none; <?php endif; ?>"><?php echo e(__('subelement')); ?></span>
                                                                                        </span>
                                                                                        <span class="item-controls">
                                                                                            <span
                                                                                                class="item-type"><?php echo e(__('Link')); ?></span>
                                                                                            <span
                                                                                                class="item-order hide-if-js">
                                                                                                <a href="<?php echo e($currentUrl); ?>?action=move-up-menu-item&menu-item=<?php echo e($m->id); ?>&_wpnonce=8b3eb7ac44"
                                                                                                    class="item-move-up"><abbr
                                                                                                        title="<?php echo e(__('move_up')); ?>">↑</abbr></a>
                                                                                                | <a href="<?php echo e($currentUrl); ?>?action=move-down-menu-item&menu-item=<?php echo e($m->id); ?>&_wpnonce=8b3eb7ac44"
                                                                                                    class="item-move-down"><abbr
                                                                                                        title="<?php echo e(__('move_down')); ?>">↓</abbr></a>
                                                                                            </span> <a
                                                                                                class="item-edit"
                                                                                                id="edit-<?php echo e($m->id); ?>"
                                                                                                title=" "
                                                                                                href="<?php echo e($currentUrl); ?>?edit-menu-item=<?php echo e($m->id); ?>#menu-item-settings-<?php echo e($m->id); ?>">
                                                                                            </a> </span>
                                                                                    </dt>
                                                                                </dl>

                                                                                <div class="menu-item-settings"
                                                                                    id="menu-item-settings-<?php echo e($m->id); ?>">
                                                                                    <input type="hidden"
                                                                                        class="edit-menu-item-id"
                                                                                        name="menuid_<?php echo e($m->id); ?>"
                                                                                        value="<?php echo e($m->id); ?>" />

                                                                                    <p
                                                                                        class="description description-thin">
                                                                                        <label
                                                                                            for="edit-menu-item-title-<?php echo e($m->id); ?>">
                                                                                            <?php echo e(__('label')); ?>

                                                                                            <br>
                                                                                            <input type="text"
                                                                                                id="idlabelmenu_<?php echo e($m->id); ?>"
                                                                                                class="widefat edit-menu-item-title"
                                                                                                name="idlabelmenu_<?php echo e($m->id); ?>"
                                                                                                value="<?php echo e($m->getTranslation($language_code)->label); ?>">
                                                                                        </label>
                                                                                    </p>


                                                                                    <p
                                                                                        class="field-css-url description description-wide">
                                                                                        <label
                                                                                            for="edit-menu-item-url-<?php echo e($m->id); ?>">
                                                                                            <?php echo e(__('URL')); ?>

                                                                                            <br>
                                                                                            <input type="text"
                                                                                                id="url_menu_<?php echo e($m->id); ?>"
                                                                                                class="widefat code edit-menu-item-url"
                                                                                                id="url_menu_<?php echo e($m->id); ?>"
                                                                                                value="<?php echo e($m->link); ?>">
                                                                                        </label>
                                                                                    </p>

                                                                                    <?php if(!empty($roles)): ?>
                                                                                        <p
                                                                                            class="field-css-role description description-wide">
                                                                                            <label
                                                                                                for="edit-menu-item-role-<?php echo e($m->id); ?>">
                                                                                                <?php echo e(__('role')); ?>

                                                                                                <br>
                                                                                                <select
                                                                                                    id="role_menu_<?php echo e($m->id); ?>"
                                                                                                    class="widefat code edit-menu-item-role"
                                                                                                    name="role_menu_[<?php echo e($m->id); ?>]">
                                                                                                    <option
                                                                                                        value="0">
                                                                                                        <?php echo e(__('select_url')); ?>

                                                                                                    </option>
                                                                                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                        <option
                                                                                                            <?php if($role->id == $m->role_id): ?> selected <?php endif; ?>
                                                                                                            value="<?php echo e($role->$role_pk); ?>">
                                                                                                            <?php echo e(ucwords($role->$role_title_field)); ?>

                                                                                                        </option>
                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                </select>
                                                                                            </label>
                                                                                        </p>
                                                                                    <?php endif; ?>

                                                                                    <div
                                                                                        class="menu-item-actions description-wide submitbox">

                                                                                        <a class="item-delete submitdelete deletion"
                                                                                            id="delete-<?php echo e($m->id); ?>"
                                                                                            href="<?php echo e($currentUrl); ?>?action=delete-menu-item&menu-item=<?php echo e($m->id); ?>&_wpnonce=2844002501"><?php echo e(__('delete')); ?></a>
                                                                                        <span
                                                                                            class="meta-sep hide-if-no-js">
                                                                                            |
                                                                                        </span>
                                                                                        <a class="item-cancel submitcancel hide-if-no-js button-secondary"
                                                                                            id="cancel-<?php echo e($m->id); ?>"
                                                                                            href="<?php echo e($currentUrl); ?>?edit-menu-item=<?php echo e($m->id); ?>&cancel=1424297719#menu-item-settings-<?php echo e($m->id); ?>"><?php echo e(__('cancel')); ?></a>
                                                                                        <span
                                                                                            class="meta-sep hide-if-no-js">
                                                                                            |
                                                                                        </span>
                                                                                        <a onclick="getmenus()"
                                                                                            class="btn btn-primary text-white updatemenu"
                                                                                            id="update-<?php echo e($m->id); ?>"
                                                                                            href="javascript:void(0)"><?php echo e(__('update_item')); ?></a>

                                                                                    </div>

                                                                                </div>
                                                                                <ul class="menu-item-transport"></ul>
                                                                            </li>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                </ul>
                                                                <div class="menu-settings">

                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="clear"></div>
                    </div>

                    <div class="clear"></div>
                </div>
                <div class="clear"></div>
            </div>

            <div class="clear"></div>
        </div>
    </div>
</div>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/Menubuilder\resources/views/menu-builder.blade.php ENDPATH**/ ?>