<script>
    var menus = {
        "oneThemeLocationNoMenus": "",
        "moveUp": '<?php echo e(__("move_up")); ?>',
        "moveDown": '<?php echo e(__("move_down")); ?>',
        "moveToTop": '<?php echo e(__("move_top")); ?>',
        "moveUnder": "Move under of %s",
        "moveOutFrom": "Out from under %s",
        "under": "Under %s",
        "outFrom": "Out from %s",
        "menuFocus": "%1\$s. Element menu %2\$d of %3\$d.",
        "enterMenuName": '<?php echo e(__("enter_menu_name")); ?>',
        "updated" : '<?php echo e(__("Updated Successfully")); ?>',
        "updateItem" : '<?php echo e(__("Item Updated Successfully")); ?>',
        "deleteItem" : '<?php echo e(__("Item deleted successfully")); ?>',
        "deleteItemAlert" : '<?php echo e(__("Do you want to delete this item ?")); ?>',
        "failed" : '<?php echo e(__("Operation Failed")); ?>',
        "subMenuFocus" : "%1\$s. Menu of subelement %2\$d of %3\$s."
    };
    var arraydata = [];
    var createnewmenur = '<?php echo e(route('admin.menus.create')); ?>';
    var generatemenucontrolr = '<?php echo e(route('admin.menus.update')); ?>';
    var deletemenugr = '<?php echo e(route('admin.menus.delete')); ?>';

    var addcustommenur = '<?php echo e(route('admin.menus.items.create')); ?>';
    var updateitemr = '<?php echo e(route('admin.menus.items.update')); ?>';
    var deleteitemmenur = '<?php echo e(route('admin.menus.items.delete')); ?>';
    var csrftoken = "<?php echo e(csrf_token()); ?>";
    var menuwr = "<?php echo e(url()->current()); ?>";

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': csrftoken
        }
    });
</script>

<script src="<?php echo e(asset('backend/menubuilder/script.js')); ?>"></script>
<script src="<?php echo e(asset('backend/menubuilder/script2.js')); ?>"></script>
<script src="<?php echo e(asset('backend/menubuilder/menu.js')); ?>"></script>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/Menubuilder\resources/views/script.blade.php ENDPATH**/ ?>