<section class="blog__post-area-seven section-pt-140 section-pb-110">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6">
                <div class="section__title text-center mb-50">
                    <span class="sub-title"><?php echo e(__('News & Blogs')); ?></span>
                    <h2 class="title bold"><?php echo e(__('Our Latest News Feed')); ?></h2>
                    <p><?php echo e(__('Dont Miss Stay Updated with the Latest Articles and Insights')); ?></p>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <?php $__currentLoopData = $featuredBlogs->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6">
                    <div class="blog__post-item-five shine__animate-item">
                        <div class="blog__post-thumb-five">
                            <a href="<?php echo e(route('blog.show', $blog->slug)); ?>" class="shine__animate-link"><img
                                    src="<?php echo e(asset($blog->image)); ?>" alt="img"></a>
                        </div>
                        <div class="blog__post-content-five">
                            <a href="<?php echo e(route('blogs', ['category' => $blog->category->slug])); ?>"
                                class="post-tag-four"><?php echo e($blog->category->translation->title); ?></a>
                            <h2 class="title"><a
                                    href="<?php echo e(route('blog.show', $blog->slug)); ?>"><?php echo e(truncate($blog->translation->title, 50)); ?></a>
                            </h2>
                            <div class="blog__post-meta">
                                <ul class="list-wrap">
                                    <li><i class="flaticon-calendar"></i><?php echo e(formatDate($blog->created_at)); ?></li>
                                    <li><i class="flaticon-user-1"></i><?php echo e(__('by')); ?> <a
                                            href="<?php echo e(route('blog.show', $blog->slug)); ?>"><?php echo e(truncate($blog->author->name, 14)); ?></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/home-four/sections/blog-area.blade.php ENDPATH**/ ?>