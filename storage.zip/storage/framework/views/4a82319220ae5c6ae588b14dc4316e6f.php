<div class="brand-area">
  <div class="container-fluid">
      <div class="marquee_mode">
        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="brand__item">
              <a href="<?php echo e($brand->url); ?>"><img src="<?php echo e(asset($brand->image)); ?>" alt="brand"></a>
              <img src="<?php echo e(asset('frontend/img/icons/brand_star.svg')); ?>" alt="star">
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
      </div>
  </div>
</div><?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/frontend/home-one/sections/brand-area.blade.php ENDPATH**/ ?>