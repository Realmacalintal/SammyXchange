<?php if(Module::isEnabled('Testimonial') && Route::has('admin.testimonial.index')): ?>
    <li class="<?php echo e(isRoute('admin.testimonial.*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.testimonial.index')); ?>">
            <i class="fas fa-comment"></i> <span><?php echo e(__('Testimonial')); ?></span>
        </a>
    </li>
<?php endif; ?>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/Testimonial\resources/views/sidebar.blade.php ENDPATH**/ ?>