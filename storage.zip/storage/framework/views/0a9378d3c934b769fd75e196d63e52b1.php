<div class="tab-pane fade" id="copyright_text_tab" role="tabpanel">
    <form action="<?php echo e(route('admin.update-copyright-text')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for=""><?php echo e(__('Copyright Text')); ?></label>
            <textarea name="copyright_text" rows="4" class="form-control h-auto"><?php echo e($setting->copyright_text); ?></textarea>
        </div>
        <button class="btn btn-primary" type="submit"><?php echo e(__('Update')); ?></button>
    </form>
</div>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/GlobalSetting\resources/views/settings/sections/copyright.blade.php ENDPATH**/ ?>