<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Email - <?php echo e(config('app.name')); ?></title>
</head>
<body>
    <p>Hello <?php echo e($user->name); ?>,</p>

    <p>Welcome to <?php echo e(config('app.name')); ?>! Your account has been created successfully.</p>

    <p>Your password: <?php echo e($password); ?></p>

    <p>You can log in to your account at <a href="<?php echo e(config('app.url')); ?>"><?php echo e(config('app.url')); ?></a></p>

    <p>Thank you for joining us.</p>
</body>
</html>
<?php /**PATH D:\laragon\www\skillgro\main_files\resources\views/emails/password-mail.blade.php ENDPATH**/ ?>