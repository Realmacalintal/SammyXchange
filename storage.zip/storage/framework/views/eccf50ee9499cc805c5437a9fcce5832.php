<li class="<?php echo e(isRoute('admin.badges.index', 'active')); ?>">
    <a class="nav-link" href="<?php echo e(route('admin.badges.index')); ?>"><i class="fas fa-award"></i>
        <span><?php echo e(__('Badges')); ?></span>
    </a>
</li><?php /**PATH D:\laragon\www\skillgro\main_files\Modules/Badges\resources/views/sidebar.blade.php ENDPATH**/ ?>