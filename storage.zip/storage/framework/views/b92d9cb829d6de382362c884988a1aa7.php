<?php if(Module::isEnabled('PageBuilder') && Route::has('admin.page-builder.index')): ?>
    <li class="<?php echo e(isRoute('admin.page-builder.*', 'active')); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.page-builder.index')); ?>">
            <i class="fas fa-file"></i> <span><?php echo e(__('Page Builder')); ?></span>
        </a>
    </li>
<?php endif; ?>
<?php /**PATH D:\laragon\www\skillgro\main_files\Modules/PageBuilder\resources/views/sidebar.blade.php ENDPATH**/ ?>